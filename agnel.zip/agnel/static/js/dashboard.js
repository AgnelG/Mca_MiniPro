window.initOfficerCharts = function ({ pieData, barLabels, barData }) {
  if (typeof Chart === 'undefined') {
    return;
  }
  const pieCanvas = document.getElementById('officerPieChart');
  const barCanvas = document.getElementById('officerBarChart');
  if (pieCanvas && pieData) {
    new Chart(pieCanvas.getContext('2d'), {
      type: 'pie',
      data: {
        labels: ['Vehicle', 'Fraud', 'Complaints', 'Other'],
        datasets: [{
          data: pieData,
          backgroundColor: ['#2563eb', '#0ea5e9', '#16a34a', '#f59e0b'],
          borderWidth: 0,
        }],
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
      },
    });
  }
  if (barCanvas && barLabels && barData) {
    new Chart(barCanvas.getContext('2d'), {
      type: 'bar',
      data: {
        labels: barLabels,
        datasets: [{
          label: 'Cases',
          data: barData,
          backgroundColor: 'rgba(37, 99, 235, 0.85)',
          borderColor: 'rgba(37, 99, 235, 1)',
          borderWidth: 1,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
        },
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true },
        },
      },
    });
  }
};
