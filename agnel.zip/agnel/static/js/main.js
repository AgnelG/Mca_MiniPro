document.addEventListener('DOMContentLoaded', function () {
  const sidebarToggles = document.querySelectorAll('[data-sidebar-toggle]');
  sidebarToggles.forEach(toggle => {
    toggle.addEventListener('click', () => {
      document.body.classList.toggle('sidebar-open');
    });
  });
});
