function initImagePreview(inputId, previewId, placeholderUrl) {
  const uploadInput = document.getElementById(inputId);
  const previewImage = document.getElementById(previewId);
  if (!uploadInput || !previewImage) {
    return;
  }
  if (placeholderUrl) {
    previewImage.dataset.placeholder = placeholderUrl;
  }
  uploadInput.addEventListener('change', function () {
    const file = uploadInput.files && uploadInput.files[0];
    if (!file) {
      previewImage.src = previewImage.dataset.placeholder || previewImage.src;
      return;
    }
    const reader = new FileReader();
    reader.onload = function (event) {
      previewImage.src = event.target.result;
    };
    reader.readAsDataURL(file);
  });
}

document.addEventListener('DOMContentLoaded', function () {
  const fileInputs = document.querySelectorAll('input[type=file]');
  fileInputs.forEach(input => {
    const previewId = input.dataset.previewTarget;
    const placeholderUrl = input.dataset.previewPlaceholder;
    if (previewId) {
      initImagePreview(input.id, previewId, placeholderUrl);
    }
  });
});
