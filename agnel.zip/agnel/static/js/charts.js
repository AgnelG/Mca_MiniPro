window.initRiskMeter = function (value) {
  const canvas = document.getElementById('riskMeter');
  if (!canvas || typeof Chart === 'undefined') {
    return;
  }
  const normalized = Math.min(Math.max(Number(value) || 0, 0), 100);
  new Chart(canvas.getContext('2d'), {
    type: 'doughnut',
    data: {
      labels: ['Risk', 'Remaining'],
      datasets: [{
        data: [normalized, 100 - normalized],
        backgroundColor: ['rgba(220, 37, 37, 0.9)', 'rgba(226, 232, 240, 0.5)'],
        borderWidth: 0,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '72%',
      plugins: {
        legend: { display: false },
        tooltip: { enabled: false },
      },
    },
  });
};

window.initOfficerCharts = function ({ pieData, pieLabels, barLabels, barData }) {
  if (typeof Chart === 'undefined') {
    return;
  }
  const pieCanvas = document.getElementById('officerPieChart');
  const barCanvas = document.getElementById('officerBarChart');
  if (pieCanvas && pieData) {
    new Chart(pieCanvas.getContext('2d'), {
      type: 'pie',
      data: {
        labels: pieLabels,
        datasets: [{
          data: pieData,
          backgroundColor: ['#2563eb', '#0ea5e9', '#16a34a', '#f59e0b'],
          borderWidth: 0,
        }],
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } },
      },
    });
  }
  if (barCanvas && barLabels && barData) {
    new Chart(barCanvas.getContext('2d'), {
      type: 'bar',
      data: {
        labels: barLabels,
        datasets: [{
          label: 'Cases',
          data: barData,
          backgroundColor: 'rgba(37, 99, 235, 0.85)',
          borderColor: 'rgba(37, 99, 235, 1)',
          borderWidth: 1,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
        },
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true },
        },
      },
    });
  }
};

window.addEventListener('DOMContentLoaded', function () {
  const chartElements = document.querySelectorAll('[data-chart]');
  chartElements.forEach(canvas => {
    const ctx = canvas.getContext('2d');
    const dataset = JSON.parse(canvas.dataset.chart || '[]');
    const labels = JSON.parse(canvas.dataset.labels || '[]');
    if (ctx && dataset.length && labels.length) {
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: canvas.dataset.label || '',
            data: dataset,
            backgroundColor: 'rgba(59, 130, 246, 0.65)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 1,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
          },
          scales: {
            x: { grid: { display: false } },
            y: { beginAtZero: true },
          },
        },
      });
    }
  });
});
