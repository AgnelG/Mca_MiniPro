from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone

from network.models import Case, Complaint, FraudReport, Notification, UserProfile, Vehicle, VehicleTheftReport

User = get_user_model()


class Command(BaseCommand):
    help = 'Create idempotent demonstration records. Pass --password to set demo account passwords.'

    def add_arguments(self, parser):
        parser.add_argument('--password', required=True, help='Password to set for created demo accounts.')

    @transaction.atomic
    def handle(self, *args, **options):
        password = options['password']
        if len(password) < 12:
            raise CommandError('The demo password must contain at least 12 characters.')
        admin = self._get_user(
            'admin@crime-shield.example', 'Portal Administrator', password,
            {'role': UserProfile.Role.ADMIN, 'is_staff': True, 'is_superuser': True},
        )
        officer = self._get_user(
            'officer@crime-shield.example', 'Demo Officer', password,
            {'role': UserProfile.Role.OFFICER},
        )
        citizen = self._get_user(
            'citizen@crime-shield.example', 'Demo Citizen', password,
            {'role': UserProfile.Role.CITIZEN, 'phone': '+910000000000'},
        )
        for user in (admin, officer, citizen):
            if not user.has_usable_password():
                user.set_password(password)
                user.save(update_fields=['password'])
        admin.is_staff = True
        admin.is_superuser = True
        admin.save(update_fields=['is_staff', 'is_superuser'])
        admin_profile, _ = UserProfile.objects.update_or_create(
            user=admin, defaults={'role': UserProfile.Role.ADMIN, 'name': 'Portal Administrator'}
        )
        officer_profile, _ = UserProfile.objects.update_or_create(
            user=officer, defaults={'role': UserProfile.Role.OFFICER, 'name': 'Demo Officer'}
        )
        citizen_profile, _ = UserProfile.objects.update_or_create(
            user=citizen,
            defaults={'role': UserProfile.Role.CITIZEN, 'name': 'Demo Citizen', 'phone': '+910000000000'},
        )

        vehicle, _ = Vehicle.objects.get_or_create(
            registration_normalized='KL01AB1234',
            defaults={
                'registration_number': 'KL-01-AB-1234', 'manufacturer': 'Demo Motors',
                'model': 'City', 'year': timezone.localdate().year - 2, 'color': 'Blue',
                'owner': citizen_profile, 'status': Vehicle.Status.STOLEN,
            },
        )

        complaint, _ = Complaint.objects.get_or_create(
            complainant=citizen_profile,
            subject='Demonstration vehicle theft report',
            defaults={
                'category': Complaint.Category.VEHICLE_THEFT,
                'description': 'Demonstration record for the report and investigation workflow.',
                'location': 'Kochi',
                'priority': Complaint.Priority.HIGH,
            },
        )
        case, _ = Case.objects.get_or_create(
            complaint=complaint,
            defaults={
                'vehicle': vehicle, 'assigned_officer': officer_profile,
                'title': complaint.subject, 'description': complaint.description,
                'category': complaint.category, 'priority': complaint.priority,
                'status': Case.Status.UNDER_INVESTIGATION,
                'assigned_at': timezone.now(), 'investigation_started_at': timezone.now(),
            },
        )
        VehicleTheftReport.objects.get_or_create(
            complaint=complaint,
            defaults={
                'vehicle': vehicle, 'reported_by': citizen_profile,
                'theft_date': timezone.localdate(), 'location': 'Kochi',
                'description': complaint.description,
                'status': VehicleTheftReport.Status.UNDER_INVESTIGATION,
            },
        )
        fraud, _ = FraudReport.objects.get_or_create(
            reported_by=citizen_profile,
            message_text='Your account will be blocked. Send your OTP immediately.',
            defaults={
                'sender': '+910000000001', 'risk_score': 80,
                'risk_level': FraudReport.RiskLevel.HIGH,
                'analysis_result': 'Requests for OTP; urgent pressure to act.',
            },
        )
        Notification.objects.get_or_create(
            user=citizen_profile, title='Demonstration case update',
            defaults={
                'message': f'Demo case {case.case_number} is under investigation.',
                'notification_type': Notification.Type.CASE,
            },
        )
        Notification.objects.get_or_create(
            user=officer_profile, title='Demonstration case assigned',
            defaults={
                'message': f'Demo case {case.case_number} has been assigned to you.',
                'notification_type': Notification.Type.CASE,
            },
        )
        Notification.objects.get_or_create(
            user=admin_profile, title='High-risk demonstration fraud report',
            defaults={
                'message': f'High-risk demo fraud report #{fraud.pk} is ready for review.',
                'notification_type': Notification.Type.FRAUD,
            },
        )
        self.stdout.write(self.style.SUCCESS(
            f'Demo records are ready: {admin.email}, {officer.email}, {citizen.email}; fraud report #{fraud.pk}.'
        ))

    @staticmethod
    def _get_user(email, name, password, defaults):
        user, created = User.objects.get_or_create(
            username=email,
            defaults={'email': email, 'first_name': name, **{
                key: value for key, value in defaults.items() if key in {'is_staff', 'is_superuser'}
            }},
        )
        if created:
            user.set_password(password)
            user.save(update_fields=['password'])
        elif not user.email:
            user.email = email
            user.save(update_fields=['email'])
        return user
