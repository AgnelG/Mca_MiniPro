from django.contrib import admin

from .models import (
    AuditLog, Case, CaseMessage, Complaint, Evidence, FraudReport, Notification,
    OwnershipHistory, UserProfile, Vehicle, VehicleTheftReport, record_audit,
)


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('name', 'user', 'role', 'phone')
    list_filter = ('role',)
    search_fields = ('name', 'phone', 'user__email')

    def save_model(self, request, obj, form, change):
        previous_role = UserProfile.objects.filter(pk=obj.pk).values_list('role', flat=True).first() if change else None
        super().save_model(request, obj, form, change)
        should_have_admin_access = obj.role == UserProfile.Role.ADMIN
        account = obj.user
        if account.is_staff != should_have_admin_access or account.is_superuser != should_have_admin_access:
            account.is_staff = should_have_admin_access
            account.is_superuser = should_have_admin_access
            account.save(update_fields=['is_staff', 'is_superuser'])
        if change and previous_role != obj.role:
            record_audit(
                request.user.network_profile, 'USER_ROLE_CHANGED', obj,
                f'User role changed from {previous_role} to {obj.role}.',
                request.META.get('REMOTE_ADDR'),
            )


@admin.register(Vehicle)
class VehicleAdmin(admin.ModelAdmin):
    list_display = ('registration_number', 'manufacturer', 'model', 'status', 'owner')
    search_fields = ('registration_number', 'vin', 'engine_number')
    list_filter = ('status',)
    readonly_fields = ('status',)

    def save_model(self, request, obj, form, change):
        previous = Vehicle.objects.filter(pk=obj.pk).values('status', 'owner_id').first() if change else None
        super().save_model(request, obj, form, change)
        old_status = previous['status'] if previous else 'new'
        record_audit(
            request.user.network_profile, 'VEHICLE_UPDATED', obj,
            f"Vehicle status {old_status} -> {obj.status}; current owner profile {obj.owner_id or 'unassigned'}.",
            request.META.get('REMOTE_ADDR'),
        )


@admin.register(Case)
class CaseAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'status', 'priority', 'assigned_officer')
    list_filter = ('status', 'priority', 'category')
    search_fields = ('title', 'complaint__subject')
    readonly_fields = ('status', 'assigned_officer')

    def save_model(self, request, obj, form, change):
        previous = Case.objects.filter(pk=obj.pk).values('status', 'assigned_officer_id').first() if change else None
        super().save_model(request, obj, form, change)
        if not previous:
            record_audit(request.user.network_profile, 'CASE_CREATED', obj, 'Case created in administration.', request.META.get('REMOTE_ADDR'))
            return
        if previous['assigned_officer_id'] != obj.assigned_officer_id:
            if obj.assigned_officer_id:
                Notification.objects.create(
                    user=obj.assigned_officer, title='New case assigned',
                    message=f'Case {obj.case_number} has been assigned to you.',
                    notification_type=Notification.Type.CASE,
                )
            record_audit(
                request.user.network_profile, 'CASE_ASSIGNED', obj,
                f'Case assigned to profile {obj.assigned_officer_id or "unassigned"}.',
                request.META.get('REMOTE_ADDR'),
            )
        if previous['status'] != obj.status:
            record_audit(
                request.user.network_profile, 'CASE_STATUS_CHANGED', obj,
                f'Case status changed from {previous["status"]} to {obj.status}.',
                request.META.get('REMOTE_ADDR'),
            )


@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('subject', 'category', 'status', 'priority', 'complainant')
    list_filter = ('category', 'status', 'priority')
    search_fields = ('subject', 'complainant__name', 'complainant__user__email')
    readonly_fields = ('status',)


@admin.register(VehicleTheftReport)
class VehicleTheftReportAdmin(admin.ModelAdmin):
    list_display = ('vehicle', 'reported_by', 'theft_date', 'status')
    readonly_fields = ('status',)


@admin.register(FraudReport)
class FraudReportAdmin(admin.ModelAdmin):
    list_display = ('reported_by', 'risk_level', 'risk_score', 'status', 'created_at')
    list_filter = ('risk_level', 'status')
    readonly_fields = ('reported_by', 'message_text', 'sender', 'risk_score', 'risk_level', 'analysis_result', 'screenshot', 'status', 'created_at')

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ('timestamp', 'user', 'action', 'model_name', 'object_id', 'ip_address')
    list_filter = ('action', 'model_name')
    search_fields = ('description', 'object_id', 'user__user__email')
    readonly_fields = ('user', 'action', 'model_name', 'object_id', 'description', 'timestamp', 'ip_address')

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


for model in (Evidence, Notification, OwnershipHistory, CaseMessage):
    admin.site.register(model)
