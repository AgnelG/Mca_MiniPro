from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm, PasswordResetForm
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.utils import timezone

from .models import (
    Case, Complaint, Evidence, FraudReport, UserProfile, Vehicle,
    engine_number_validator, vin_validator,
)

User = get_user_model()


class LoginForm(AuthenticationForm):
    username = forms.CharField(label='Email or username', widget=forms.TextInput(attrs={'autocomplete': 'username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'autocomplete': 'current-password'}))


class RegistrationForm(forms.Form):
    full_name = forms.CharField(max_length=150)
    email = forms.EmailField(max_length=150)
    phone = forms.CharField(max_length=20, required=False)
    password1 = forms.CharField(widget=forms.PasswordInput, validators=[validate_password])
    password2 = forms.CharField(widget=forms.PasswordInput)

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise ValidationError('An account with this email already exists.')
        return email

    def clean_phone(self):
        phone = self.cleaned_data['phone'].strip()
        if phone and not phone.replace('+', '').replace('-', '').replace(' ', '').isdigit():
            raise ValidationError('Enter a valid phone number.')
        return phone

    def clean(self):
        cleaned = super().clean()
        if cleaned.get('password1') and cleaned.get('password2') and cleaned['password1'] != cleaned['password2']:
            self.add_error('password2', 'The passwords do not match.')
        return cleaned

    def save(self):
        email = self.cleaned_data['email']
        name = self.cleaned_data['full_name'].strip()
        user = User.objects.create_user(
            username=email, email=email, password=self.cleaned_data['password1'],
            first_name=name,
        )
        profile, _ = UserProfile.objects.get_or_create(
            user=user,
            defaults={'name': name, 'phone': self.cleaned_data['phone']},
        )
        if profile.name != name or profile.phone != self.cleaned_data['phone']:
            profile.name = name
            profile.phone = self.cleaned_data['phone']
            profile.save(update_fields=['name', 'phone'])
        return user


class ComplaintForm(forms.ModelForm):
    date_reported = forms.DateField(
        required=False, initial=timezone.localdate,
        widget=forms.DateInput(attrs={'type': 'date'}),
    )
    evidence = forms.FileField(required=False)

    class Meta:
        model = Complaint
        fields = ['subject', 'category', 'description', 'location', 'priority']
        widgets = {'description': forms.Textarea(attrs={'rows': 5})}

    def clean_evidence(self):
        upload = self.cleaned_data.get('evidence')
        if upload:
            _validate_allowed_file(upload)
        return upload


class VehicleTheftForm(forms.Form):
    registration_number = forms.CharField(max_length=20, validators=[Vehicle._meta.get_field('registration_number').validators[0]])
    vin = forms.CharField(max_length=17, required=False, validators=[vin_validator])
    engine_number = forms.CharField(max_length=32, required=False, validators=[engine_number_validator])
    owner_name = forms.CharField(max_length=150, required=False)
    brand = forms.CharField(max_length=80, label='Vehicle Make')
    model = forms.CharField(max_length=80)
    vehicle_type = forms.ChoiceField(choices=Vehicle.Type.choices)
    year = forms.IntegerField(min_value=1900, max_value=timezone.localdate().year + 1, required=False)
    color = forms.CharField(max_length=40)
    missing_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    missing_time = forms.TimeField(required=False, widget=forms.TimeInput(attrs={'type': 'time'}))
    location = forms.CharField(max_length=200)
    description = forms.CharField(widget=forms.Textarea(attrs={'rows': 4}))
    image = forms.FileField(required=False)

    def __init__(self, *args, user=None, **kwargs):
        self.user = user
        is_bound = bool(args and args[0] is not None) or kwargs.get('data') is not None
        if user and not is_bound:
            initial = kwargs.setdefault('initial', {})
            initial.setdefault('owner_name', user.name)
        super().__init__(*args, **kwargs)

    def clean_owner_name(self):
        owner_name = self.cleaned_data['owner_name'].strip()
        if owner_name and self.user and owner_name.casefold() != self.user.name.casefold():
            raise ValidationError('The owner name must match the name on your citizen account.')
        return owner_name

    def clean_registration_number(self):
        return self.cleaned_data['registration_number'].strip().upper()

    def clean_image(self):
        upload = self.cleaned_data.get('image')
        if upload:
            _validate_allowed_file(upload, image_only=True)
        return upload

    def clean(self):
        cleaned = super().clean()
        normalized_registration = ''.join(
            character for character in cleaned.get('registration_number', '').upper()
            if character.isalnum()
        )
        existing = Vehicle.objects.filter(registration_normalized=normalized_registration).first()
        for field_name in ('vin', 'engine_number'):
            value = cleaned.get(field_name)
            if value:
                duplicates = Vehicle.objects.filter(**{f'{field_name}__iexact': value})
                if existing:
                    duplicates = duplicates.exclude(pk=existing.pk)
                if duplicates.exists():
                    self.add_error(field_name, 'This identifier is already registered.')
        theft_date = cleaned.get('missing_date')
        if theft_date and theft_date > timezone.localdate():
            self.add_error('missing_date', 'The theft date cannot be in the future.')
        return cleaned


class FraudCheckForm(forms.Form):
    phone_number = forms.CharField(max_length=30, required=False, label='Phone Number')
    message = forms.CharField(widget=forms.Textarea(attrs={'rows': 4}), max_length=10000)
    screenshot = forms.FileField(required=False)

    def clean_phone_number(self):
        phone = self.cleaned_data['phone_number'].strip()
        if phone and not phone.replace('+', '').replace('-', '').replace(' ', '').isdigit():
            raise ValidationError('Enter a valid phone number.')
        return phone

    def clean_screenshot(self):
        upload = self.cleaned_data.get('screenshot')
        if upload:
            _validate_allowed_file(upload, image_only=True)
        return upload


class EvidenceForm(forms.ModelForm):
    evidence_type = forms.ChoiceField(choices=Evidence.Type.choices)

    class Meta:
        model = Evidence
        fields = ['evidence_type', 'file', 'description']

    def clean_file(self):
        upload = self.cleaned_data['file']
        _validate_allowed_file(upload)
        return upload


class CaseStatusForm(forms.ModelForm):
    class Meta:
        model = Case
        fields = ['status']


class CaseAssignmentForm(forms.ModelForm):
    assigned_officer = forms.ModelChoiceField(
        queryset=UserProfile.objects.filter(role=UserProfile.Role.OFFICER, user__is_active=True),
        required=False,
    )

    class Meta:
        model = Case
        fields = ['assigned_officer']


class ProfileForm(forms.Form):
    name = forms.CharField(max_length=150)
    email = forms.EmailField(max_length=150)
    phone = forms.CharField(max_length=20, required=False)

    def __init__(self, *args, profile, **kwargs):
        self.profile = profile
        kwargs.setdefault('initial', {
            'name': profile.name,
            'email': profile.user.email,
            'phone': profile.phone,
        })
        super().__init__(*args, **kwargs)

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email__iexact=email).exclude(pk=self.profile.user_id).exists():
            raise ValidationError('An account with this email already exists.')
        return email

    def clean_phone(self):
        phone = self.cleaned_data['phone'].strip()
        if phone and not phone.replace('+', '').replace('-', '').replace(' ', '').isdigit():
            raise ValidationError('Enter a valid phone number.')
        return phone

    def save(self):
        self.profile.name = self.cleaned_data['name'].strip()
        self.profile.phone = self.cleaned_data['phone'].strip()
        self.profile.save(update_fields=['name', 'phone'])
        self.profile.user.email = self.cleaned_data['email']
        self.profile.user.username = self.cleaned_data['email']
        self.profile.user.first_name = self.cleaned_data['name'].strip()
        self.profile.user.save(update_fields=['email', 'username', 'first_name'])
        return self.profile


class EmailPasswordResetForm(PasswordResetForm):
    email = forms.EmailField()


def _validate_allowed_file(upload, image_only=False):
    allowed = {'jpg', 'jpeg', 'png', 'gif'} if image_only else {
        'jpg', 'jpeg', 'png', 'gif', 'pdf', 'mp4', 'mov', 'avi', 'doc', 'docx', 'txt', 'csv',
    }
    extension = upload.name.rsplit('.', 1)[-1].lower() if '.' in upload.name else ''
    if extension not in allowed:
        raise ValidationError('Choose a supported image, PDF, or video file.')
    if upload.size > 8 * 1024 * 1024:
        raise ValidationError('Files must be no larger than 8 MB.')
