import tempfile
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.utils import timezone

from .models import (
    AuditLog, Case, Complaint, Evidence, FraudReport, Notification, OwnershipHistory,
    UserProfile, Vehicle, VehicleTheftReport, transfer_vehicle_ownership,
)

User = get_user_model()


class CrimeShieldWorkflowTests(TestCase):
    def setUp(self):
        self.media_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.media_directory.cleanup)
        media_override = override_settings(MEDIA_ROOT=self.media_directory.name)
        media_override.enable()
        self.addCleanup(media_override.disable)
        self.citizen = self.create_profile('citizen@example.test', 'Asha Citizen', UserProfile.Role.CITIZEN)
        self.officer = self.create_profile('officer@example.test', 'Officer Rao', UserProfile.Role.OFFICER)
        self.admin = self.create_profile('admin@example.test', 'Portal Admin', UserProfile.Role.ADMIN)

    @staticmethod
    def create_profile(email, name, role):
        user = User.objects.create_user(
            username=email, email=email, password='StrongPassword4!', first_name=name
        )
        profile = user.network_profile
        profile.name = name
        profile.role = role
        profile.save(update_fields=['name', 'role'])
        return profile

    def submit_theft_report(self):
        self.client.force_login(self.citizen.user)
        response = self.client.post('/vehicles/report/', {
            'registration_number': 'KL-01-AB-1234',
            'owner_name': self.citizen.name,
            'vin': '1HGCM82633A004352',
            'engine_number': 'ENG-123456',
            'brand': 'Demo Motors',
            'model': 'City',
            'vehicle_type': Vehicle.Type.CAR,
            'year': timezone.localdate().year - 2,
            'color': 'Blue',
            'missing_date': (timezone.localdate() - timedelta(days=1)).isoformat(),
            'missing_time': '18:30',
            'location': 'Central Market',
            'description': 'Vehicle was missing after work.',
        })
        self.assertEqual(response.status_code, 302)

    def test_login_navigation_and_manual_logout_for_all_roles(self):
        self.assertFalse(getattr(settings, 'SESSION_EXPIRE_AT_BROWSER_CLOSE', False))
        role_pages = (
            (self.citizen, '/citizen/dashboard/'),
            (self.officer, '/officer/dashboard/'),
            (self.admin, '/admin/dashboard/'),
        )

        for profile, protected_page in role_pages:
            with self.subTest(role=profile.role):
                response = self.client.post('/accounts/login/', {
                    'username': profile.user.username,
                    'password': 'StrongPassword4!',
                })
                self.assertRedirects(
                    response,
                    {
                        UserProfile.Role.CITIZEN: '/citizen/dashboard/',
                        UserProfile.Role.OFFICER: '/officer/dashboard/',
                        UserProfile.Role.ADMIN: '/admin/dashboard/',
                    }[profile.role],
                    fetch_redirect_response=False,
                )
                session_cookie = self.client.cookies[settings.SESSION_COOKIE_NAME]
                self.assertTrue(session_cookie.get('expires'))
                self.assertTrue(session_cookie.get('max-age'))
                self.assertEqual(self.client.get(protected_page).status_code, 200)

                logout_response = self.client.post('/accounts/logout/')
                self.assertRedirects(logout_response, '/', fetch_redirect_response=False)
                self.assertRedirects(
                    self.client.get(protected_page),
                    '/accounts/login/?next=' + protected_page,
                    fetch_redirect_response=False,
                )

    def test_missing_vehicle_registration_is_visible_to_citizen_and_case_workflow(self):
        self.client.force_login(self.citizen.user)
        form_response = self.client.get('/vehicles/report/')
        self.assertEqual(form_response.status_code, 200)
        self.assertContains(form_response, 'Vehicle Type')
        self.assertContains(form_response, 'id_vehicle_type')

        photo = SimpleUploadedFile('vehicle.jpg', b'photo bytes', content_type='image/jpeg')
        response = self.client.post('/vehicles/report/', {
            'registration_number': 'KL-01-AB-1234',
            'brand': 'Demo Motors',
            'model': 'City',
            'vehicle_type': Vehicle.Type.CAR,
            'color': 'Blue',
            'missing_date': (timezone.localdate() - timedelta(days=1)).isoformat(),
            'missing_time': '18:30',
            'location': 'Central Market',
            'description': 'Blue car last seen near the central market.',
            'image': photo,
        })
        self.assertEqual(response.status_code, 302)
        vehicle = Vehicle.objects.get(registration_normalized='KL01AB1234')
        report = VehicleTheftReport.objects.get(vehicle=vehicle)
        case = Case.objects.get(complaint=report.complaint)
        self.assertEqual(vehicle.owner, self.citizen)
        self.assertEqual(vehicle.vehicle_type, Vehicle.Type.CAR)
        self.assertEqual(report.reported_by, self.citizen)
        self.assertEqual(report.theft_time.strftime('%H:%M'), '18:30')
        evidence = Evidence.objects.get(case=case)
        self.assertEqual(evidence.uploaded_by, self.citizen)
        self.assertEqual(evidence.evidence_type, Evidence.Type.IMAGE)
        self.assertEqual(response.url, f'/vehicles/details/{vehicle.pk}/')
        self.assertContains(self.client.get(response.url), case.case_number)

        dashboard = self.client.get('/citizen/dashboard/')
        self.assertContains(dashboard, vehicle.registration_number)
        self.assertContains(dashboard, case.case_number)

        self.client.force_login(self.admin.user)
        self.assertContains(self.client.get('/admin/cases/'), case.case_number)
        assignment_response = self.client.post(f'/officer/cases/{case.pk}/', {
            'action': 'assign',
            'assignment-assigned_officer': self.officer.pk,
        })
        self.assertEqual(assignment_response.status_code, 302)
        case.refresh_from_db()
        self.assertEqual(case.assigned_officer, self.officer)

        self.client.force_login(self.officer.user)
        self.assertContains(self.client.get('/officer/cases/'), case.case_number)
        officer_dashboard = self.client.get('/officer/dashboard/')
        self.assertContains(officer_dashboard, vehicle.registration_number)
        self.assertContains(officer_dashboard, 'Car')
        self.assertContains(officer_dashboard, case.case_number)
        self.assertContains(officer_dashboard, 'New case assigned')

    def test_missing_vehicle_registration_rejects_invalid_and_unauthorized_requests(self):
        self.assertEqual(self.client.get('/vehicles/report/').status_code, 302)

        self.client.force_login(self.citizen.user)
        response = self.client.post('/vehicles/report/', {
            'registration_number': 'not-a-registration',
            'brand': '',
            'model': '',
            'vehicle_type': 'INVALID',
            'color': '',
            'missing_date': '',
            'location': '',
            'description': '',
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Enter a valid vehicle registration number.')
        self.assertEqual(Vehicle.objects.count(), 0)
        self.assertEqual(VehicleTheftReport.objects.count(), 0)
        self.assertEqual(Case.objects.count(), 0)

        other_citizen = self.create_profile(
            'other-citizen@example.test', 'Other Citizen', UserProfile.Role.CITIZEN
        )
        self.client.force_login(other_citizen.user)
        self.client.post('/vehicles/report/', {
            'registration_number': 'MH-12-XY-5678',
            'brand': 'Other Motors',
            'model': 'Roadster',
            'vehicle_type': Vehicle.Type.MOTORCYCLE,
            'color': 'Black',
            'missing_date': (timezone.localdate() - timedelta(days=1)).isoformat(),
            'location': 'Other Street',
            'description': 'Other citizen vehicle report.',
        })
        vehicle = Vehicle.objects.get(registration_normalized='MH12XY5678')
        self.client.force_login(self.citizen.user)
        other_report_response = self.client.get(f'/vehicles/details/{vehicle.pk}/')
        self.assertEqual(other_report_response.status_code, 200)
        self.assertNotContains(other_report_response, 'Reported Location')

    def test_reporting_existing_owned_vehicle_updates_vehicle_without_duplicates(self):
        vehicle = Vehicle.objects.create(
            registration_number='KL-01-AB-1234',
            manufacturer='Old Make',
            model='Old Model',
            color='Silver',
            owner=self.citizen,
        )
        self.client.force_login(self.citizen.user)
        response = self.client.post('/vehicles/report/', {
            'registration_number': 'KL01AB1234',
            'brand': 'Updated Make',
            'model': 'Updated Model',
            'vehicle_type': Vehicle.Type.CAR,
            'color': 'Blue',
            'year': timezone.localdate().year - 1,
            'missing_date': (timezone.localdate() - timedelta(days=1)).isoformat(),
            'location': 'Central Market',
            'description': 'The already registered vehicle is missing.',
        })

        self.assertEqual(response.status_code, 302)
        vehicle.refresh_from_db()
        self.assertEqual(vehicle.owner, self.citizen)
        self.assertEqual(vehicle.manufacturer, 'Updated Make')
        self.assertEqual(vehicle.model, 'Updated Model')
        self.assertEqual(vehicle.vehicle_type, Vehicle.Type.CAR)
        self.assertEqual(vehicle.color, 'Blue')
        self.assertEqual(Vehicle.objects.count(), 1)
        self.assertEqual(VehicleTheftReport.objects.count(), 1)
        self.assertEqual(Complaint.objects.count(), 1)
        self.assertEqual(Case.objects.count(), 1)

    def test_citizen_complaint_creates_case_and_notifications(self):
        self.client.force_login(self.citizen.user)
        response = self.client.post('/complaints/create/', {
            'subject': 'Suspicious activity near my home',
            'category': Complaint.Category.SUSPICIOUS_ACTIVITY,
            'description': 'A person was checking parked vehicles.',
            'location': 'Main Street',
            'priority': Complaint.Priority.HIGH,
        })
        self.assertEqual(response.status_code, 302)
        complaint = Complaint.objects.get(complainant=self.citizen)
        case = Case.objects.get(complaint=complaint)
        self.assertEqual(case.status, Case.Status.OPEN)
        self.assertTrue(Notification.objects.filter(user=self.citizen, notification_type=Notification.Type.COMPLAINT).exists())
        self.assertTrue(Notification.objects.filter(user=self.officer, notification_type=Notification.Type.COMPLAINT).exists())
        self.assertTrue(AuditLog.objects.filter(action='COMPLAINT_CREATED', object_id=str(complaint.pk)).exists())

        self.client.get(f'/complaints/details/{complaint.pk}/')
        other_citizen = self.create_profile('other@example.test', 'Other Citizen', UserProfile.Role.CITIZEN)
        self.client.force_login(other_citizen.user)
        self.assertEqual(self.client.get(f'/complaints/details/{complaint.pk}/').status_code, 403)

    def test_vehicle_theft_search_assignment_evidence_and_resolution(self):
        self.submit_theft_report()
        vehicle = Vehicle.objects.get(registration_normalized='KL01AB1234')
        report = VehicleTheftReport.objects.get(vehicle=vehicle)
        case = Case.objects.get(complaint=report.complaint)
        self.assertEqual(vehicle.status, Vehicle.Status.REPORTED_MISSING)
        self.assertTrue(OwnershipHistory.objects.filter(vehicle=vehicle, owner=self.citizen).exists())
        self.assertTrue(Notification.objects.filter(user=self.officer, notification_type=Notification.Type.CASE).exists())

        self.client.logout()
        public_response = self.client.get('/vehicles/search/?q=KL-01-AB-1234')
        self.assertContains(public_response, 'KL-01-AB-1234')
        detail_response = self.client.get(f'/vehicles/details/{vehicle.pk}/')
        self.assertContains(detail_response, 'Vehicle reported missing')
        self.assertNotContains(detail_response, self.citizen.name)

        self.client.force_login(self.admin.user)
        assignment_response = self.client.post(f'/officer/cases/{case.pk}/', {
            'action': 'assign',
            'assignment-assigned_officer': self.officer.pk,
        })
        self.assertEqual(assignment_response.status_code, 302)
        case.refresh_from_db()
        self.assertEqual(case.assigned_officer, self.officer)
        self.assertTrue(Notification.objects.filter(user=self.officer, title='New case assigned').exists())
        self.assertTrue(AuditLog.objects.filter(action='CASE_ASSIGNED', object_id=str(case.pk)).exists())

        self.client.force_login(self.officer.user)
        self.assertContains(self.client.get('/officer/cases/'), case.case_number)
        self.assertContains(self.client.get(f'/officer/cases/{case.pk}/'), 'Upload Evidence')
        evidence = SimpleUploadedFile('evidence.pdf', b'%PDF-1.4 evidence', content_type='application/pdf')
        upload_response = self.client.post(f'/officer/cases/{case.pk}/', {
            'action': 'evidence',
            'evidence-evidence_type': 'DOCUMENT',
            'evidence-description': 'Scene report',
            'evidence-file': evidence,
        })
        self.assertEqual(upload_response.status_code, 302)
        saved_evidence = Evidence.objects.get(case=case)
        self.assertEqual(saved_evidence.uploaded_by, self.officer)
        download_response = self.client.get(f'/cases/evidence/{saved_evidence.pk}/')
        self.assertEqual(download_response.status_code, 200)
        download_response.close()
        self.client.logout()
        self.assertEqual(self.client.get(f'/cases/evidence/{saved_evidence.pk}/').status_code, 302)
        self.client.force_login(self.officer.user)

        response = self.client.post(f'/officer/cases/{case.pk}/', {
            'action': 'status',
            'status-status': Case.Status.UNDER_INVESTIGATION,
        })
        self.assertEqual(response.status_code, 302)
        response = self.client.post(f'/officer/cases/{case.pk}/', {
            'action': 'status',
            'status-status': Case.Status.RESOLVED,
        })
        self.assertEqual(response.status_code, 302)
        case.refresh_from_db()
        vehicle.refresh_from_db()
        report.refresh_from_db()
        self.assertEqual(case.status, Case.Status.RESOLVED)
        self.assertEqual(vehicle.status, Vehicle.Status.RECOVERED)
        self.assertEqual(report.status, VehicleTheftReport.Status.RECOVERED)
        self.assertEqual(case.complaint.status, Complaint.Status.RESOLVED)
        self.assertTrue(Notification.objects.filter(user=self.citizen, title='Complaint status updated').exists())
        self.assertTrue(AuditLog.objects.filter(action='VEHICLE_UPDATED', object_id=str(vehicle.pk)).exists())

    def test_officer_can_add_private_investigation_note_to_assigned_case(self):
        complaint = Complaint.objects.create(
            complainant=self.citizen,
            subject='Investigation note test',
            category=Complaint.Category.SUSPICIOUS_ACTIVITY,
            description='A reported incident requires follow-up.',
            location='Central District',
        )
        case = Case.objects.create(
            complaint=complaint,
            assigned_officer=self.officer,
            title=complaint.subject,
            category=complaint.category,
        )
        self.client.force_login(self.officer.user)
        details = self.client.get(f'/officer/cases/{case.pk}/')
        self.assertContains(details, 'Add investigation note')
        self.assertContains(details, 'Review linked complaint')

        response = self.client.post(f'/officer/cases/{case.pk}/', {
            'action': 'investigation_note',
            'investigation_note': 'Witness interviewed; follow-up scheduled.',
        })
        self.assertRedirects(
            response, f'/officer/cases/{case.pk}/', fetch_redirect_response=False
        )
        note = AuditLog.objects.get(
            action='INVESTIGATION_NOTE_ADDED', object_id=str(case.pk)
        )
        self.assertEqual(note.user, self.officer)
        self.assertIn('Witness interviewed', note.description)
        self.assertContains(
            self.client.get(f'/officer/cases/{case.pk}/'),
            'Witness interviewed; follow-up scheduled.',
        )
        self.client.force_login(self.admin.user)
        self.assertEqual(self.client.post(f'/officer/cases/{case.pk}/', {
            'action': 'investigation_note',
            'investigation_note': 'Unauthorized note attempt.',
        }).status_code, 403)
        self.assertFalse(AuditLog.objects.filter(
            action='INVESTIGATION_NOTE_ADDED',
            description__contains='Unauthorized note attempt',
        ).exists())

    def test_role_boundary_and_duplicate_vehicle_reporting(self):
        self.client.force_login(self.citizen.user)
        self.assertEqual(self.client.get('/officer/dashboard/').status_code, 403)
        self.submit_theft_report()
        self.client.force_login(self.citizen.user)
        response = self.client.post('/vehicles/report/', {
            'registration_number': 'KL01AB1234',
            'owner_name': self.citizen.name,
            'brand': 'Demo Motors',
            'model': 'City',
            'vehicle_type': Vehicle.Type.CAR,
            'color': 'Blue',
            'missing_date': (timezone.localdate() - timedelta(days=1)).isoformat(),
            'location': 'Central Market',
            'description': 'Duplicate report.',
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(VehicleTheftReport.objects.count(), 1)
        self.assertContains(response, 'active theft report already exists')

    def test_registration_hashes_password_and_fraud_check_is_persisted(self):
        response = self.client.post('/accounts/register/', {
            'full_name': 'New Citizen',
            'email': 'newcitizen@example.test',
            'phone': '+919876543210',
            'password1': 'StrongPassword!4829',
            'password2': 'StrongPassword!4829',
        })
        self.assertEqual(response.status_code, 302)
        user = User.objects.get(email='newcitizen@example.test')
        self.assertNotEqual(user.password, 'StrongPassword!4829')
        self.assertTrue(user.check_password('StrongPassword!4829'))
        self.assertEqual(user.network_profile.role, UserProfile.Role.CITIZEN)
        self.assertContains(self.client.get('/accounts/profile/'), 'New Citizen')
        profile_response = self.client.post('/accounts/profile/', {
            'name': 'New Citizen Updated',
            'email': 'newcitizen@example.test',
            'phone': '+919876543210',
        })
        self.assertEqual(profile_response.status_code, 302)
        user.network_profile.refresh_from_db()
        self.assertEqual(user.network_profile.name, 'New Citizen Updated')

        self.client.force_login(user)
        response = self.client.post('/fraud/check/', {
            'phone_number': '+919876543211',
            'message': 'Police will block your account immediately. Send your OTP and pay an urgent fee at https://example.invalid',
        })
        self.assertEqual(response.status_code, 302)
        report = FraudReport.objects.get(reported_by=user.network_profile)
        self.assertEqual(report.risk_level, FraudReport.RiskLevel.HIGH)
        self.assertGreater(report.risk_score, 0)
        self.assertTrue(Notification.objects.filter(user=self.officer, notification_type=Notification.Type.FRAUD).exists())
        self.assertContains(self.client.get('/fraud/result/'), 'Risk assessment result')

    def test_vehicle_ownership_transfers_keep_the_timeline(self):
        vehicle = Vehicle.objects.create(
            registration_number='MH-12-XY-7890',
            manufacturer='Demo Motors',
            model='Tourer',
            owner=self.citizen,
        )
        previous = vehicle.ownership_history.get(end_date__isnull=True)
        next_owner = self.create_profile('buyer@example.test', 'Buyer Citizen', UserProfile.Role.CITIZEN)
        transfer_vehicle_ownership(vehicle, next_owner, 'Private sale')
        previous.refresh_from_db()
        vehicle.refresh_from_db()
        current = vehicle.ownership_history.get(end_date__isnull=True)
        self.assertEqual(previous.owner, self.citizen)
        self.assertIsNotNone(previous.end_date)
        self.assertEqual(current.owner, next_owner)
        self.assertEqual(current.transfer_reason, 'Private sale')
        self.assertEqual(vehicle.owner, next_owner)

    def test_demo_data_command_is_repeatable(self):
        call_command('seed_demo_data', password='SecureDemoPassword!4928', verbosity=0)
        call_command('seed_demo_data', password='SecureDemoPassword!4928', verbosity=0)
        self.assertEqual(User.objects.count(), 6)
        self.assertEqual(Vehicle.objects.count(), 1)
        self.assertEqual(Complaint.objects.count(), 1)
        self.assertEqual(Case.objects.count(), 1)
        self.assertEqual(VehicleTheftReport.objects.count(), 1)
        self.assertEqual(FraudReport.objects.count(), 1)
        self.assertEqual(OwnershipHistory.objects.count(), 1)

    def test_dashboards_and_cases_are_scoped_to_the_signed_in_role(self):
        citizen_complaint = Complaint.objects.create(
            complainant=self.citizen,
            subject='My case',
            category=Complaint.Category.OTHER,
            description='Citizen-owned complaint.',
            location='Central Station',
        )
        assigned_case = Case.objects.create(
            complaint=citizen_complaint,
            assigned_officer=self.officer,
            title='My assigned case',
            category=citizen_complaint.category,
            priority=Complaint.Priority.CRITICAL,
            status=Case.Status.UNDER_INVESTIGATION,
        )
        other_officer = self.create_profile(
            'other-officer@example.test', 'Other Officer', UserProfile.Role.OFFICER
        )
        other_citizen = self.create_profile(
            'other-citizen@example.test', 'Other Citizen', UserProfile.Role.CITIZEN
        )
        private_complaint = Complaint.objects.create(
            complainant=other_citizen,
            subject='Private case',
            category=Complaint.Category.FRAUD,
            description='Belongs to another officer.',
        )
        private_case = Case.objects.create(
            complaint=private_complaint,
            assigned_officer=other_officer,
            title='Another officer case',
            category=private_complaint.category,
        )

        self.client.force_login(self.officer.user)
        dashboard = self.client.get('/officer/dashboard/')
        self.assertEqual(dashboard.context['total_cases'], 1)
        self.assertEqual(dashboard.context['under_investigation_cases'], 1)
        self.assertContains(dashboard, 'Central Station')
        self.assertContains(dashboard, assigned_case.case_number)
        self.assertNotContains(dashboard, private_case.case_number)
        cases_response = self.client.get('/officer/cases/')
        self.assertContains(cases_response, assigned_case.case_number)
        self.assertNotContains(cases_response, private_case.case_number)
        self.assertEqual(self.client.get(f'/officer/cases/{private_case.pk}/').status_code, 403)

        self.client.force_login(self.citizen.user)
        citizen_dashboard = self.client.get('/citizen/dashboard/')
        self.assertEqual(citizen_dashboard.context['complaint_count'], 1)
        self.assertEqual(citizen_dashboard.context['active_case_count'], 1)
        self.assertEqual(self.client.get(f'/complaints/details/{private_complaint.pk}/').status_code, 403)

        self.client.force_login(self.admin.user)
        admin_dashboard = self.client.get('/admin/dashboard/')
        self.assertEqual(admin_dashboard.context['total_users'], 5)
        self.assertEqual(admin_dashboard.context['total_complaints'], 2)
