from django.db import migrations


def create_profiles_for_existing_users(apps, schema_editor):
    AuthUser = apps.get_model('auth', 'User')
    UserProfile = apps.get_model('network', 'UserProfile')
    database = schema_editor.connection.alias
    for user in AuthUser.objects.using(database).iterator():
        name = ' '.join(part for part in (user.first_name, user.last_name) if part).strip()
        name = name or user.email or user.username
        role = 'ADMIN' if user.is_staff or user.is_superuser else 'CITIZEN'
        UserProfile.objects.using(database).get_or_create(
            user_id=user.pk,
            defaults={'name': name, 'role': role},
        )


class Migration(migrations.Migration):
    dependencies = [
        ('network', '0001_initial'),
        ('auth', '0012_alter_user_first_name_max_length'),
    ]

    operations = [
        migrations.RunPython(create_profiles_for_existing_users, migrations.RunPython.noop),
    ]
