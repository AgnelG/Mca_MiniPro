from django.contrib.auth import get_user_model
from django.contrib.auth.signals import user_logged_in, user_logged_out
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import AuditLog, UserProfile


@receiver(post_save, sender=get_user_model())
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.get_or_create(
            user=instance,
            defaults={
                'name': instance.get_full_name() or instance.email or instance.get_username(),
                'role': UserProfile.Role.ADMIN if instance.is_superuser else UserProfile.Role.CITIZEN,
            },
        )


def write_auth_audit(action, request, user):
    if not user:
        return
    profile, _ = UserProfile.objects.get_or_create(
        user=user,
        defaults={
            'name': user.get_full_name() or user.email or user.get_username(),
            'role': UserProfile.Role.ADMIN if user.is_superuser else UserProfile.Role.CITIZEN,
        },
    )
    AuditLog.objects.create(
        user=profile,
        action=action,
        model_name=user._meta.label,
        object_id=str(user.pk),
        description='User signed in.' if action == 'USER_LOGIN' else 'User signed out.',
        ip_address=request.META.get('REMOTE_ADDR') if request else None,
    )


@receiver(user_logged_in)
def audit_login(sender, request, user, **kwargs):
    write_auth_audit('USER_LOGIN', request, user)


@receiver(user_logged_out)
def audit_logout(sender, request, user, **kwargs):
    write_auth_audit('USER_LOGOUT', request, user)
