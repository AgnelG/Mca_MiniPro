import re

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator, RegexValidator
from django.db import models, transaction
from django.utils import timezone


def validate_upload_size(upload):
    if upload.size > 8 * 1024 * 1024:
        raise ValidationError('Files must be no larger than 8 MB.')


def normalize_registration(value):
    return re.sub(r'[\s-]+', '', value or '').upper()


registration_validator = RegexValidator(
    regex=r'^[A-Za-z]{2}[\s-]?\d{1,2}[\s-]?[A-Za-z]{1,3}[\s-]?\d{1,4}$',
    message='Enter a valid vehicle registration number.',
)
vin_validator = RegexValidator(
    regex=r'^[A-HJ-NPR-Z0-9]{17}$',
    message='Enter a valid 17-character VIN (I, O, and Q are not allowed).',
    flags=re.IGNORECASE,
)
engine_number_validator = RegexValidator(
    regex=r'^[A-Za-z0-9-]{5,32}$',
    message='Enter an engine number containing 5 to 32 letters, numbers, or hyphens.',
)


class UserProfile(models.Model):
    class Role(models.TextChoices):
        CITIZEN = 'CITIZEN', 'Citizen'
        OFFICER = 'OFFICER', 'Officer'
        ADMIN = 'ADMIN', 'Admin'

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, related_name='network_profile', on_delete=models.CASCADE
    )
    name = models.CharField(max_length=150)
    phone = models.CharField(max_length=20, blank=True)
    role = models.CharField(max_length=10, choices=Role.choices, default=Role.CITIZEN)

    @property
    def email(self):
        return self.user.email

    @property
    def is_active(self):
        return self.user.is_active

    def __str__(self):
        return self.name or self.user.email


class Vehicle(models.Model):
    class Type(models.TextChoices):
        CAR = 'CAR', 'Car'
        MOTORCYCLE = 'MOTORCYCLE', 'Motorcycle'
        SCOOTER = 'SCOOTER', 'Scooter'
        BUS = 'BUS', 'Bus'
        TRUCK = 'TRUCK', 'Truck'
        VAN = 'VAN', 'Van'
        OTHER = 'OTHER', 'Other'

    class Status(models.TextChoices):
        ACTIVE = 'ACTIVE', 'Active'
        REPORTED_MISSING = 'REPORTED_MISSING', 'Reported Missing'
        STOLEN = 'STOLEN', 'Stolen'
        UNDER_INVESTIGATION = 'UNDER_INVESTIGATION', 'Under Investigation'
        RECOVERED = 'RECOVERED', 'Recovered'
        CLOSED = 'CLOSED', 'Closed'

    registration_number = models.CharField(max_length=20, validators=[registration_validator])
    registration_normalized = models.CharField(max_length=20, unique=True, editable=False)
    vin = models.CharField(max_length=17, blank=True, null=True, unique=True, validators=[vin_validator])
    engine_number = models.CharField(max_length=32, blank=True, null=True, unique=True, validators=[engine_number_validator])
    manufacturer = models.CharField(max_length=80, blank=True)
    model = models.CharField(max_length=80)
    vehicle_type = models.CharField(max_length=12, choices=Type.choices, default=Type.OTHER)
    year = models.PositiveSmallIntegerField(null=True, blank=True)
    color = models.CharField(max_length=40, blank=True)
    fuel_type = models.CharField(max_length=30, blank=True)
    owner = models.ForeignKey(
        UserProfile, related_name='owned_vehicles', on_delete=models.SET_NULL, null=True, blank=True
    )
    status = models.CharField(max_length=24, choices=Status.choices, default=Status.ACTIVE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['registration_number']

    def save(self, *args, **kwargs):
        self.registration_number = self.registration_number.strip().upper()
        self.registration_normalized = normalize_registration(self.registration_number)
        if self.vin:
            self.vin = self.vin.strip().upper()
        if self.engine_number:
            self.engine_number = self.engine_number.strip().upper()
        update_fields = kwargs.get('update_fields')
        owner_is_being_saved = update_fields is None or 'owner' in update_fields
        previous_owner_id = None
        is_new = self.pk is None
        if not is_new and owner_is_being_saved:
            previous_owner_id = type(self).objects.filter(pk=self.pk).values_list('owner_id', flat=True).first()
        with transaction.atomic():
            super().save(*args, **kwargs)
            if owner_is_being_saved and (is_new or previous_owner_id != self.owner_id):
                current = self.ownership_history.filter(end_date__isnull=True).first()
                if current:
                    current.end_date = timezone.localdate()
                    current.save(update_fields=['end_date'])
                if self.owner_id:
                    OwnershipHistory.objects.create(
                        vehicle=self,
                        owner_id=self.owner_id,
                        start_date=timezone.localdate(),
                        transfer_reason=getattr(self, '_transfer_reason', ''),
                    )
                if hasattr(self, '_transfer_reason'):
                    del self._transfer_reason

    @property
    def brand(self):
        return self.manufacturer

    @property
    def registration(self):
        return self.registration_number

    @property
    def status_badge(self):
        return 'danger' if self.status in {self.Status.STOLEN, self.Status.REPORTED_MISSING} else 'success'

    @property
    def missing_date(self):
        latest = self.theft_reports.order_by('-created_at').first()
        return latest.theft_date if latest else None

    def __str__(self):
        return self.registration_number


class Complaint(models.Model):
    class Category(models.TextChoices):
        VEHICLE_THEFT = 'Vehicle Theft', 'Vehicle Theft'
        FRAUD = 'Fraud', 'Fraud'
        CYBER_CRIME = 'Cyber Crime', 'Cyber Crime'
        MISSING_VEHICLE = 'Missing Vehicle', 'Missing Vehicle'
        SUSPICIOUS_ACTIVITY = 'Suspicious Activity', 'Suspicious Activity'
        OTHER = 'Other', 'Other'

    class Status(models.TextChoices):
        SUBMITTED = 'SUBMITTED', 'Submitted'
        UNDER_REVIEW = 'UNDER_REVIEW', 'Under Review'
        ASSIGNED = 'ASSIGNED', 'Assigned'
        UNDER_INVESTIGATION = 'UNDER_INVESTIGATION', 'Under Investigation'
        RESOLVED = 'RESOLVED', 'Resolved'
        REJECTED = 'REJECTED', 'Rejected'
        CLOSED = 'CLOSED', 'Closed'

    class Priority(models.TextChoices):
        LOW = 'LOW', 'Low'
        MEDIUM = 'MEDIUM', 'Medium'
        HIGH = 'HIGH', 'High'
        CRITICAL = 'CRITICAL', 'Critical'

    complainant = models.ForeignKey(UserProfile, related_name='complaints', on_delete=models.PROTECT)
    category = models.CharField(max_length=30, choices=Category.choices, default=Category.OTHER)
    subject = models.CharField(max_length=160)
    description = models.TextField()
    location = models.CharField(max_length=200, blank=True)
    priority = models.CharField(max_length=10, choices=Priority.choices, default=Priority.MEDIUM)
    status = models.CharField(max_length=24, choices=Status.choices, default=Status.SUBMITTED)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    @property
    def reference_number(self):
        return f'C-{self.pk:03d}'

    @property
    def date_reported(self):
        return self.created_at

    @property
    def reporter_name(self):
        return self.complainant.name

    @property
    def assigned_officer(self):
        case = getattr(self, 'case', None)
        return case.assigned_officer.name if case and case.assigned_officer else None

    @property
    def review_date(self):
        case = getattr(self, 'case', None)
        return case.review_started_at if case else None

    @property
    def investigation_date(self):
        case = getattr(self, 'case', None)
        return case.investigation_started_at if case else None

    @property
    def resolved_date(self):
        case = getattr(self, 'case', None)
        return case.resolved_at if case else None

    @property
    def status_badge(self):
        return 'success' if self.status == self.Status.RESOLVED else 'warning'

    def __str__(self):
        return f'{self.reference_number}: {self.subject}'


class Case(models.Model):
    class Status(models.TextChoices):
        OPEN = 'OPEN', 'Open'
        UNDER_REVIEW = 'UNDER_REVIEW', 'Under Review'
        UNDER_INVESTIGATION = 'UNDER_INVESTIGATION', 'Under Investigation'
        RESOLVED = 'RESOLVED', 'Resolved'
        CLOSED = 'CLOSED', 'Closed'

    complaint = models.OneToOneField(
        Complaint, related_name='case', on_delete=models.CASCADE, null=True, blank=True
    )
    vehicle = models.ForeignKey(
        Vehicle, related_name='cases', on_delete=models.SET_NULL, null=True, blank=True
    )
    assigned_officer = models.ForeignKey(
        UserProfile, related_name='assigned_cases', on_delete=models.SET_NULL, null=True, blank=True,
        limit_choices_to={'role': UserProfile.Role.OFFICER},
    )
    title = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=30, choices=Complaint.Category.choices)
    priority = models.CharField(max_length=10, choices=Complaint.Priority.choices, default=Complaint.Priority.MEDIUM)
    status = models.CharField(max_length=24, choices=Status.choices, default=Status.OPEN)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    assigned_at = models.DateTimeField(null=True, blank=True)
    review_started_at = models.DateTimeField(null=True, blank=True)
    investigation_started_at = models.DateTimeField(null=True, blank=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-updated_at']

    @property
    def case_number(self):
        return f'CS-{self.pk:04d}'

    @property
    def case_type(self):
        return self.category

    @property
    def reporter_name(self):
        return self.complaint.complainant.name if self.complaint_id else 'Vehicle report'

    @property
    def status_badge(self):
        return 'success' if self.status in {self.Status.RESOLVED, self.Status.CLOSED} else 'warning'

    @property
    def opened_date(self):
        return self.created_at

    @property
    def evidence_summary(self):
        return f'{self.evidence.count()} attachment(s)' if self.evidence.exists() else 'No evidence uploaded yet.'

    def __str__(self):
        return f'{self.case_number}: {self.title}'


class VehicleTheftReport(models.Model):
    class Status(models.TextChoices):
        SUBMITTED = 'SUBMITTED', 'Submitted'
        UNDER_INVESTIGATION = 'UNDER_INVESTIGATION', 'Under Investigation'
        RECOVERED = 'RECOVERED', 'Recovered'
        CLOSED = 'CLOSED', 'Closed'

    vehicle = models.ForeignKey(Vehicle, related_name='theft_reports', on_delete=models.PROTECT)
    reported_by = models.ForeignKey(UserProfile, related_name='theft_reports', on_delete=models.PROTECT)
    theft_date = models.DateField()
    theft_time = models.TimeField(null=True, blank=True)
    location = models.CharField(max_length=200)
    description = models.TextField()
    complaint = models.ForeignKey(Complaint, related_name='theft_reports', on_delete=models.CASCADE)
    status = models.CharField(max_length=24, choices=Status.choices, default=Status.SUBMITTED)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def complaint_number(self):
        return self.complaint.reference_number


class Evidence(models.Model):
    class Type(models.TextChoices):
        IMAGE = 'IMAGE', 'Image'
        DOCUMENT = 'DOCUMENT', 'Document'
        VIDEO = 'VIDEO', 'Video'
        OTHER = 'OTHER', 'Other'

    case = models.ForeignKey(Case, related_name='evidence', on_delete=models.CASCADE)
    uploaded_by = models.ForeignKey(UserProfile, related_name='uploaded_evidence', on_delete=models.PROTECT)
    evidence_type = models.CharField(max_length=30, choices=Type.choices, default=Type.DOCUMENT)
    file = models.FileField(
        upload_to='case-evidence/%Y/%m/',
        validators=[validate_upload_size, FileExtensionValidator([
            'jpg', 'jpeg', 'png', 'gif', 'pdf', 'mp4', 'mov', 'avi', 'doc', 'docx', 'txt', 'csv',
        ])],
    )
    description = models.CharField(max_length=300, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)


class FraudReport(models.Model):
    class RiskLevel(models.TextChoices):
        LOW = 'LOW', 'Low'
        MEDIUM = 'MEDIUM', 'Medium'
        HIGH = 'HIGH', 'High'

    class Status(models.TextChoices):
        SUBMITTED = 'SUBMITTED', 'Submitted'
        REVIEWED = 'REVIEWED', 'Reviewed'
        CLOSED = 'CLOSED', 'Closed'

    reported_by = models.ForeignKey(UserProfile, related_name='fraud_reports', on_delete=models.CASCADE)
    message_text = models.TextField()
    sender = models.CharField(max_length=30, blank=True)
    risk_score = models.PositiveSmallIntegerField()
    risk_level = models.CharField(max_length=10, choices=RiskLevel.choices)
    analysis_result = models.TextField()
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.SUBMITTED)
    screenshot = models.FileField(
        upload_to='fraud-evidence/%Y/%m/', blank=True,
        validators=[validate_upload_size, FileExtensionValidator(['jpg', 'jpeg', 'png', 'gif'])],
    )
    created_at = models.DateTimeField(auto_now_add=True)


class Notification(models.Model):
    class Type(models.TextChoices):
        COMPLAINT = 'COMPLAINT', 'Complaint'
        CASE = 'CASE', 'Case'
        VEHICLE = 'VEHICLE', 'Vehicle'
        FRAUD = 'FRAUD', 'Fraud'
        SYSTEM = 'SYSTEM', 'System'

    user = models.ForeignKey(UserProfile, related_name='notifications', on_delete=models.CASCADE)
    title = models.CharField(max_length=160)
    message = models.TextField()
    notification_type = models.CharField(max_length=12, choices=Type.choices, default=Type.SYSTEM)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']


class CaseMessage(models.Model):
    case = models.ForeignKey(Case, related_name='messages', on_delete=models.CASCADE)
    sender = models.ForeignKey(UserProfile, related_name='case_messages', on_delete=models.PROTECT)
    message = models.TextField(max_length=4000)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']


class OwnershipHistory(models.Model):
    vehicle = models.ForeignKey(Vehicle, related_name='ownership_history', on_delete=models.CASCADE)
    owner = models.ForeignKey(UserProfile, related_name='vehicle_ownerships', on_delete=models.PROTECT)
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    transfer_reason = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['start_date', 'created_at']


class AuditLog(models.Model):
    user = models.ForeignKey(UserProfile, related_name='audit_logs', on_delete=models.SET_NULL, null=True, blank=True)
    action = models.CharField(max_length=40)
    model_name = models.CharField(max_length=80)
    object_id = models.CharField(max_length=64)
    description = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ['-timestamp']


def record_audit(user, action, instance, description, ip_address=None):
    AuditLog.objects.create(
        user=user if isinstance(user, UserProfile) else None,
        action=action,
        model_name=instance._meta.label,
        object_id=str(instance.pk),
        description=description,
        ip_address=ip_address,
    )


def transfer_vehicle_ownership(vehicle, owner, transfer_reason=''):
    current = vehicle.ownership_history.filter(end_date__isnull=True).first()
    if current and current.owner_id == owner.pk:
        return current
    vehicle._transfer_reason = transfer_reason
    vehicle.owner = owner
    vehicle.save(update_fields=['owner', 'updated_at'])
    return vehicle.ownership_history.filter(end_date__isnull=True).first()
