import re
from datetime import timedelta
from functools import wraps
from pathlib import Path

from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Count, Q
from django.http import FileResponse, HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render, reverse
from django.utils import timezone

from network.forms import (
    CaseAssignmentForm, CaseStatusForm, ComplaintForm, EmailPasswordResetForm,
    EvidenceForm, FraudCheckForm, LoginForm, ProfileForm, RegistrationForm,
    VehicleTheftForm,
)
from network.models import (
    AuditLog, Case, CaseMessage, Complaint, Evidence, FraudReport, Notification,
    UserProfile, Vehicle, VehicleTheftReport, normalize_registration, record_audit,
)


def profile_for(user):
    if not user.is_authenticated:
        return None
    profile, _ = UserProfile.objects.get_or_create(
        user=user,
        defaults={
            'name': user.get_full_name() or user.email or user.get_username(),
            'role': UserProfile.Role.ADMIN if user.is_superuser else UserProfile.Role.CITIZEN,
        },
    )
    return profile


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(request, *args, **kwargs):
            request.profile = profile_for(request.user)
            if request.profile.role not in roles:
                return HttpResponseForbidden('You do not have permission to access this page.')
            return view(request, *args, **kwargs)
        return wrapped
    return decorator


def request_ip(request):
    return request.META.get('REMOTE_ADDR')


def notify_user(user, title, message, notification_type):
    if user and user.is_active:
        Notification.objects.create(
            user=user, title=title, message=message, notification_type=notification_type
        )


def notify_staff(title, message, notification_type):
    for recipient in UserProfile.objects.filter(
        role__in=[UserProfile.Role.OFFICER, UserProfile.Role.ADMIN], user__is_active=True
    ):
        notify_user(recipient, title, message, notification_type)


def home(request):
    reported_vehicles = Vehicle.objects.filter(
        status__in=[Vehicle.Status.STOLEN, Vehicle.Status.REPORTED_MISSING]
    )
    recent_alerts = [
        {
            'title': 'Vehicle reported missing',
            'location': 'Location withheld while the case is investigated',
            'timestamp': report.created_at,
            'severity': report.complaint.get_priority_display(),
            'summary': 'A vehicle theft report has been received by the portal.',
        }
        for report in VehicleTheftReport.objects.select_related('vehicle', 'complaint')
        .filter(vehicle__status__in=[Vehicle.Status.STOLEN, Vehicle.Status.REPORTED_MISSING])
        .order_by('-created_at')[:5]
    ]
    return render(request, 'home.html', {
        'total_cases': Case.objects.count(),
        'total_reports': Complaint.objects.count(),
        'recent_alerts': recent_alerts,
        'total_citizens': UserProfile.objects.filter(role=UserProfile.Role.CITIZEN).count(),
        'total_fraud_cases': FraudReport.objects.count(),
        'total_resolved': Case.objects.filter(status=Case.Status.RESOLVED).count(),
        'officer_count': UserProfile.objects.filter(
            role=UserProfile.Role.OFFICER, user__is_active=True
        ).count(),
        'reported_vehicle_count': reported_vehicles.count(),
        'active_alert': reported_vehicles.exists(),
    })


@role_required(UserProfile.Role.CITIZEN)
def vehicle_report(request):
    form = VehicleTheftForm(request.POST or None, request.FILES or None, user=request.profile)
    if request.method == 'POST' and form.is_valid():
        data = form.cleaned_data
        normalized = normalize_registration(data['registration_number'])
        with transaction.atomic():
            vehicle = Vehicle.objects.select_for_update().filter(registration_normalized=normalized).first()
            if vehicle:
                if vehicle.owner_id != request.profile.pk:
                    form.add_error(
                        'registration_number',
                        'This registration is already on record and cannot be reported by this account.',
                    )
                elif vehicle.status in {Vehicle.Status.STOLEN, Vehicle.Status.REPORTED_MISSING}:
                    form.add_error('registration_number', 'An active theft report already exists for this vehicle.')
            if not form.errors:
                if not vehicle:
                    vehicle = Vehicle.objects.create(
                        registration_number=data['registration_number'],
                        manufacturer=data['brand'],
                        model=data['model'],
                        vehicle_type=data['vehicle_type'],
                        vin=data['vin'] or None,
                        engine_number=data['engine_number'] or None,
                        year=data['year'],
                        color=data['color'],
                        owner=request.profile,
                        status=Vehicle.Status.REPORTED_MISSING,
                    )
                else:
                    vehicle.manufacturer = data['brand']
                    vehicle.model = data['model']
                    vehicle.vehicle_type = data['vehicle_type']
                    vehicle.color = data['color']
                    update_fields = [
                        'manufacturer', 'model', 'vehicle_type', 'color',
                        'status', 'updated_at',
                    ]
                    if data['vin']:
                        vehicle.vin = data['vin']
                        update_fields.append('vin')
                    if data['engine_number']:
                        vehicle.engine_number = data['engine_number']
                        update_fields.append('engine_number')
                    if data['year'] is not None:
                        vehicle.year = data['year']
                        update_fields.append('year')
                    vehicle.status = Vehicle.Status.REPORTED_MISSING
                    vehicle.save(update_fields=update_fields)
                complaint = Complaint.objects.create(
                    complainant=request.profile,
                    category=Complaint.Category.VEHICLE_THEFT,
                    subject=f'Stolen vehicle report: {vehicle.registration_number}',
                    description=data['description'],
                    location=data['location'],
                    priority=Complaint.Priority.HIGH,
                )
                case = Case.objects.create(
                    complaint=complaint,
                    vehicle=vehicle,
                    title=complaint.subject,
                    description=complaint.description,
                    category=complaint.category,
                    priority=complaint.priority,
                )
                theft_report = VehicleTheftReport.objects.create(
                    vehicle=vehicle,
                    reported_by=request.profile,
                    theft_date=data['missing_date'],
                    theft_time=data['missing_time'],
                    location=data['location'],
                    description=data['description'],
                    complaint=complaint,
                )
                if data.get('image'):
                    Evidence.objects.create(
                        case=case, uploaded_by=request.profile, evidence_type='IMAGE',
                        file=data['image'], description='Image attached to theft report',
                    )
                notify_user(
                    request.profile, 'Vehicle theft report received',
                    f'Your report for {vehicle.registration_number} is now case {case.case_number}.',
                    Notification.Type.VEHICLE,
                )
                notify_staff(
                    'New vehicle theft report',
                    f'Case {case.case_number} has been created for {vehicle.registration_number}.',
                    Notification.Type.CASE,
                )
                record_audit(request.profile, 'VEHICLE_THEFT_REPORTED', theft_report, 'Vehicle theft report submitted.', request_ip(request))
                record_audit(request.profile, 'CASE_CREATED', case, 'Case created from a vehicle theft report.', request_ip(request))
                messages.success(
                    request,
                    f'Your missing vehicle report was submitted. Reference: {case.case_number}.',
                )
                return redirect('vehicles_details', vehicle_id=vehicle.pk)
    return render(request, 'vehicles/report.html', {'form': form})


def vehicle_search(request):
    vehicles = Vehicle.objects.all()
    query = request.GET.get('q', '').strip()
    if query:
        normalized = normalize_registration(query)
        if normalized:
            vehicles = vehicles.filter(
                Q(registration_normalized__icontains=normalized)
                | Q(manufacturer__icontains=query)
                | Q(model__icontains=query)
                | Q(color__icontains=query)
            )
        else:
            vehicles = vehicles.none()
    status = request.GET.get('status', '').strip().upper()
    status_map = {
        'MISSING': Vehicle.Status.REPORTED_MISSING,
        'UNDER_REVIEW': Vehicle.Status.UNDER_INVESTIGATION,
    }
    if status:
        vehicles = vehicles.filter(status=status_map.get(status, status))
    case_type = request.GET.get('case_type', '').strip().lower()
    if case_type == 'theft':
        vehicles = vehicles.filter(theft_reports__isnull=False)
    elif case_type == 'fraud':
        vehicles = vehicles.filter(cases__category=Complaint.Category.FRAUD)
    elif case_type == 'complaint':
        vehicles = vehicles.filter(cases__complaint__isnull=False)
    vehicles = vehicles.distinct().order_by('registration_number')
    return render(request, 'vehicles/search.html', {
        'vehicles': vehicles,
        'search_count': vehicles.count(),
        'request': request,
    })


def vehicle_details(request, vehicle_id):
    vehicle = get_object_or_404(
        Vehicle.objects.prefetch_related('theft_reports', 'ownership_history__owner', 'cases'),
        pk=vehicle_id,
    )
    profile = profile_for(request.user)
    case = None
    private_view = False
    if profile:
        if profile.role == UserProfile.Role.ADMIN:
            private_view = True
            case = vehicle.cases.order_by('-created_at').first()
        elif profile.role == UserProfile.Role.OFFICER:
            case = vehicle.cases.filter(
                Q(assigned_officer=profile) | Q(assigned_officer__isnull=True)
            ).order_by('-created_at').first()
            private_view = case is not None
        else:
            private_view = (
                vehicle.owner_id == profile.pk
                or vehicle.theft_reports.filter(reported_by=profile).exists()
            )
            case = vehicle.cases.filter(complaint__complainant=profile).order_by('-created_at').first()
    latest_report = None
    if private_view:
        reports = vehicle.theft_reports.order_by('-created_at')
        if profile.role == UserProfile.Role.OFFICER and case:
            reports = reports.filter(complaint__case=case)
        elif profile.role == UserProfile.Role.CITIZEN:
            reports = reports.filter(reported_by=profile)
        latest_report = reports.first()
    return render(request, 'vehicles/details.html', {
        'vehicle': vehicle,
        'private_view': private_view,
        'latest_report': latest_report,
        'ownership_history': vehicle.ownership_history.all() if private_view else [],
        'case': case,
    })


@role_required(UserProfile.Role.OFFICER, UserProfile.Role.ADMIN)
def contact_reporter(request, case_id):
    case = _accessible_case(request.profile, case_id)
    if request.method == 'POST':
        text = request.POST.get('message', '').strip()
        if not text or len(text) > 4000:
            messages.error(request, 'Enter a message of 1 to 4000 characters.')
        else:
            CaseMessage.objects.create(case=case, sender=request.profile, message=text)
            if case.complaint_id:
                notify_user(
                    case.complaint.complainant, 'Update from your case officer',
                    f'An officer sent an update for case {case.case_number}.',
                    Notification.Type.CASE,
                )
            record_audit(request.profile, 'CASE_MESSAGE_SENT', case, 'A case message was sent to the reporter.', request_ip(request))
            messages.success(request, 'Message sent to the reporter.')
            return redirect('vehicles_contact', case_id=case.pk)
    return render(request, 'vehicles/contact.html', {
        'conversation': [
            {
                'sender': message.sender.name,
                'timestamp': message.created_at,
                'text': message.message,
                'sent_by_user': message.sender_id == request.profile.pk,
            }
            for message in case.messages.select_related('sender')
        ],
        'case': case,
    })


@role_required(UserProfile.Role.CITIZEN)
def fraud_check(request):
    form = FraudCheckForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        message = form.cleaned_data['message']
        score, reasons = analyze_fraud_message(message, form.cleaned_data['phone_number'])
        level = FraudReport.RiskLevel.HIGH if score >= 60 else FraudReport.RiskLevel.MEDIUM if score >= 30 else FraudReport.RiskLevel.LOW
        report = FraudReport.objects.create(
            reported_by=request.profile,
            message_text=message,
            sender=form.cleaned_data['phone_number'],
            risk_score=score,
            risk_level=level,
            analysis_result='; '.join(reasons) if reasons else 'No common scam indicators were detected.',
            screenshot=form.cleaned_data.get('screenshot'),
        )
        record_audit(request.profile, 'FRAUD_REPORT_CREATED', report, 'A suspicious message was analyzed.', request_ip(request))
        if level == FraudReport.RiskLevel.HIGH:
            notify_staff('High-risk fraud report submitted', f'A high-risk fraud message was submitted (report #{report.pk}).', Notification.Type.FRAUD)
        request.session['latest_fraud_report_id'] = report.pk
        return redirect('fraud_result')
    reports = FraudReport.objects.filter(reported_by=request.profile).order_by('-created_at')[:5]
    return render(request, 'fraud/check.html', {'form': form, 'reports': reports})


def analyze_fraud_message(message, sender=''):
    text = message.lower()
    indicators = {
        'Requests for an OTP, password, PIN, or banking details': r'\b(otp|one.time.password|password|pin|bank details|cvv)\b',
        'Urgent threats or pressure to act immediately': r'\b(urgent|immediately|suspend|blocked|expire|arrest)\b',
        'Requests for money, fees, or prize payments': r'\b(pay|payment|fee|prize|lottery|transfer|refund)\b',
        'Suspicious links or shortened URLs': r'(https?://|www\.|bit\.ly|tinyurl)',
        'Impersonation of government or law enforcement': r'\b(police|government|tax|court|customs)\b',
    }
    reasons = [reason for reason, pattern in indicators.items() if re.search(pattern, text)]
    score = min(100, len(reasons) * 20 + (10 if sender and not sender.startswith('+') else 0))
    return score, reasons


@role_required(UserProfile.Role.CITIZEN)
def fraud_result(request):
    report_id = request.session.pop('latest_fraud_report_id', None)
    report = FraudReport.objects.filter(pk=report_id, reported_by=request.profile).first() if report_id else None
    if not report:
        report = FraudReport.objects.filter(reported_by=request.profile).order_by('-created_at').first()
    if not report:
        messages.info(request, 'Submit a message for analysis to see a fraud risk assessment.')
        return redirect('fraud_check')
    reasons = report.analysis_result.split('; ') if report.analysis_result else []
    return render(request, 'fraud/result.html', {
        'report': report,
        'risk_value': report.risk_score,
        'risk_style': {'HIGH': 'danger', 'MEDIUM': 'warning', 'LOW': 'success'}[report.risk_level],
        'risk_badge': f'{report.get_risk_level_display()} Risk',
        'risk_summary': report.analysis_result,
        'reasons': reasons,
        'recommendations': [
            'Never share OTPs, passwords, or banking details in response to an unsolicited message.',
            'Verify the sender using contact details from an official source.',
            'Do not open suspicious links or make payments under pressure.',
        ],
    })


@role_required(UserProfile.Role.CITIZEN)
def complaint_create(request):
    form = ComplaintForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        with transaction.atomic():
            complaint = form.save(commit=False)
            complaint.complainant = request.profile
            complaint.save()
            case = Case.objects.create(
                complaint=complaint, title=complaint.subject, description=complaint.description,
                category=complaint.category, priority=complaint.priority,
            )
            if form.cleaned_data.get('evidence'):
                Evidence.objects.create(
                    case=case, uploaded_by=request.profile, evidence_type='DOCUMENT',
                    file=form.cleaned_data['evidence'], description='Evidence submitted with complaint',
                )
            notify_user(
                request.profile, 'Complaint received',
                f'Your complaint {complaint.reference_number} has been received.',
                Notification.Type.COMPLAINT,
            )
            notify_staff(
                'New complaint submitted',
                f'{complaint.reference_number}: {complaint.subject}',
                Notification.Type.COMPLAINT,
            )
            record_audit(request.profile, 'COMPLAINT_CREATED', complaint, 'A citizen complaint was submitted.', request_ip(request))
            record_audit(request.profile, 'CASE_CREATED', case, 'Case created from a citizen complaint.', request_ip(request))
        messages.success(request, 'Your complaint has been received.')
        return redirect('complaints_details', complaint_id=complaint.pk)
    return render(request, 'complaints/create.html', {'form': form})


@login_required
def complaint_list(request):
    profile = profile_for(request.user)
    complaints = Complaint.objects.select_related('complainant')
    if profile.role == UserProfile.Role.CITIZEN:
        complaints = complaints.filter(complainant=profile)
    elif profile.role == UserProfile.Role.OFFICER:
        complaints = complaints.filter(
            Q(case__assigned_officer=profile) | Q(case__assigned_officer__isnull=True)
        )
    query = request.GET.get('q', '').strip()
    if query:
        complaints = complaints.filter(
            Q(subject__icontains=query) | Q(description__icontains=query)
        )
    status = request.GET.get('status', '').strip()
    if status:
        complaints = complaints.filter(status=status)
    category = request.GET.get('category', '').strip()
    if category:
        complaints = complaints.filter(category=category)
    return render(request, 'complaints/list.html', {'complaints': complaints})


@login_required
def complaint_details(request, complaint_id):
    profile = profile_for(request.user)
    complaint = get_object_or_404(
        Complaint.objects.select_related('complainant').prefetch_related('case__evidence'),
        pk=complaint_id,
    )
    if profile.role == UserProfile.Role.CITIZEN and complaint.complainant_id != profile.pk:
        raise PermissionDenied
    if profile.role == UserProfile.Role.OFFICER:
        if not hasattr(complaint, 'case') or complaint.case.assigned_officer_id not in {None, profile.pk}:
            raise PermissionDenied
    case = getattr(complaint, 'case', None)
    timeline = [
        {'title': 'Complaint submitted', 'timestamp': complaint.created_at},
    ]
    if case:
        timeline.append({'title': 'Investigation case created', 'timestamp': case.created_at})
        if case.assigned_at:
            timeline.append({'title': 'Officer assigned', 'timestamp': case.assigned_at})
        if case.review_started_at:
            timeline.append({'title': 'Under review', 'timestamp': case.review_started_at})
        if case.investigation_started_at:
            timeline.append({'title': 'Investigation started', 'timestamp': case.investigation_started_at})
        if case.resolved_at:
            timeline.append({'title': 'Case resolved', 'timestamp': case.resolved_at})
        timeline.extend(
            {
                'title': f'Evidence uploaded: {evidence.description or evidence.get_evidence_type_display()}',
                'timestamp': evidence.uploaded_at,
            }
            for evidence in case.evidence.all()
        )
        timeline.sort(key=lambda event: event['timestamp'])
    context = {
        'complaint': complaint,
        'timeline': timeline,
        'case': case,
        'review_date': case.review_started_at if case else None,
        'investigation_date': case.investigation_started_at if case else None,
        'resolved_date': case.resolved_at if case else None,
        'reporter_name': complaint.complainant.name if profile.role != UserProfile.Role.CITIZEN else 'You',
        'assigned_officer': case.assigned_officer.name if case and case.assigned_officer else 'Not assigned',
        'urgency': complaint.get_priority_display(),
    }
    return render(request, 'complaints/details.html', context)


@login_required
def notifications_list(request):
    profile = profile_for(request.user)
    if request.method == 'POST' and request.POST.get('mark_all') == '1':
        Notification.objects.filter(user=profile, is_read=False).update(is_read=True)
        return redirect('notifications_list')
    unread = Notification.objects.filter(user=profile, is_read=False)
    read = Notification.objects.filter(user=profile, is_read=True)
    if request.method == 'POST':
        notification_id = request.POST.get('notification_id')
        if notification_id:
            Notification.objects.filter(pk=notification_id, user=profile).update(is_read=True)
            return redirect('notifications_list')
    return render(request, 'notifications/list.html', {
        'unread_notifications': unread,
        'read_notifications': read,
    })


def login_view(request):
    form = LoginForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.get_user()
        login(request, user)
        profile = profile_for(user)
        if profile.role == UserProfile.Role.OFFICER:
            return redirect('officer_dashboard')
        if profile.role == UserProfile.Role.ADMIN:
            return redirect('admin_dashboard')
        return redirect('citizen_dashboard')
    return render(request, 'accounts/login.html', {'form': form})


def register_view(request):
    form = RegistrationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        profile = profile_for(user)
        record_audit(profile, 'USER_REGISTERED', profile, 'Citizen account registered.', request_ip(request))
        messages.success(request, 'Your account was created.')
        return redirect('citizen_dashboard')
    return render(request, 'accounts/register.html', {'form': form})


def password_reset_view(request):
    form = EmailPasswordResetForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save(
            request=request,
            use_https=request.is_secure(),
            email_template_name='registration/password_reset_email.html',
            subject_template_name='registration/password_reset_subject.txt',
        )
        messages.success(request, 'If an account exists for that email, password reset instructions have been sent.')
        return redirect('accounts_password_reset')
    return render(request, 'accounts/password_reset.html', {'form': form})


@login_required
def logout_view(request):
    if request.method != 'POST':
        raise PermissionDenied
    profile = profile_for(request.user)
    logout(request)
    return redirect('home')


@login_required
def profile_view(request):
    profile = profile_for(request.user)
    form = ProfileForm(request.POST or None, profile=profile)
    if request.method == 'POST' and form.is_valid():
        profile = form.save()
        record_audit(profile, 'PROFILE_UPDATED', profile, 'User profile updated.', request_ip(request))
        messages.success(request, 'Your profile was updated.')
        return redirect('accounts_profile')
    return render(request, 'accounts/profile.html', {
        'user': request.user,
        'profile': profile,
        'form': form,
    })


@role_required(UserProfile.Role.CITIZEN)
def citizen_dashboard(request):
    profile = request.profile
    complaints = Complaint.objects.filter(complainant=profile)
    notifications = Notification.objects.filter(user=profile)
    activity = []
    activity.extend(
        {
            'title': complaint.subject,
            'timestamp': complaint.updated_at,
            'category': complaint.get_category_display(),
            'description': f'Status: {complaint.get_status_display()}',
        }
        for complaint in complaints[:5]
    )
    activity.extend(
        {
            'title': notification.title,
            'timestamp': notification.created_at,
            'category': notification.get_notification_type_display(),
            'description': notification.message,
        }
        for notification in notifications[:5]
    )
    activity.sort(key=lambda item: item['timestamp'], reverse=True)
    return render(request, 'citizen/dashboard.html', {
        'report_count': VehicleTheftReport.objects.filter(reported_by=profile).count(),
        'vehicle_reports': VehicleTheftReport.objects.filter(
            reported_by=profile
        ).select_related('vehicle', 'complaint').order_by('-created_at'),
        'complaint_count': complaints.count(),
        'fraud_report_count': FraudReport.objects.filter(reported_by=profile).count(),
        'active_case_count': Case.objects.filter(complaint__complainant=profile).exclude(
            status__in=[Case.Status.RESOLVED, Case.Status.CLOSED]
        ).count(),
        'resolved_case_count': Case.objects.filter(
            complaint__complainant=profile, status=Case.Status.RESOLVED
        ).count(),
        'unread_notification_count': notifications.filter(is_read=False).count(),
        'recent_activity': activity[:8],
    })


@role_required(UserProfile.Role.OFFICER)
def officer_dashboard(request):
    profile = request.profile
    assigned_cases = Case.objects.filter(assigned_officer=profile).select_related(
        'complaint__complainant', 'assigned_officer', 'vehicle'
    )
    recent_cases = assigned_cases.order_by('-updated_at')[:8]
    notifications = Notification.objects.filter(user=profile).order_by('-created_at')[:5]
    assigned_vehicle_reports = VehicleTheftReport.objects.select_related(
        'vehicle', 'complaint', 'complaint__case'
    ).filter(complaint__case__assigned_officer=profile).order_by('-created_at')[:6]
    return render(request, 'officer/dashboard.html', {
        'total_cases': assigned_cases.count(),
        'pending_cases': assigned_cases.filter(status__in=[Case.Status.OPEN, Case.Status.UNDER_REVIEW]).count(),
        'under_investigation_cases': assigned_cases.filter(status=Case.Status.UNDER_INVESTIGATION).count(),
        'resolved_cases': assigned_cases.filter(status=Case.Status.RESOLVED).count(),
        'complaints_total': Complaint.objects.filter(case__in=assigned_cases).count(),
        'recent_cases': recent_cases,
        'high_priority_cases': assigned_cases.filter(priority__in=[Complaint.Priority.HIGH, Complaint.Priority.CRITICAL]).count(),
        'assigned_vehicle_reports': assigned_vehicle_reports,
        'recent_notifications': notifications,
        'unread_notification_count': Notification.objects.filter(user=profile, is_read=False).count(),
        'profile': profile,
    })


@role_required(UserProfile.Role.OFFICER, UserProfile.Role.ADMIN)
def officer_cases(request):
    cases = Case.objects.select_related('complaint__complainant', 'assigned_officer', 'vehicle')
    if request.profile.role == UserProfile.Role.OFFICER:
        cases = cases.filter(Q(assigned_officer=request.profile) | Q(assigned_officer__isnull=True))
    query = request.GET.get('q', '').strip()
    if query:
        cases = cases.filter(
            Q(title__icontains=query)
            | Q(complaint__complainant__name__icontains=query)
            | Q(vehicle__registration_number__icontains=query)
        )
    status = request.GET.get('status', '').strip()
    if status:
        cases = cases.filter(status=status)
    elif request.profile.role == UserProfile.Role.OFFICER:
        cases = cases.filter(Q(assigned_officer=request.profile) | Q(assigned_officer__isnull=True))
    category = request.GET.get('category', '').strip()
    if category:
        cases = cases.filter(category=category)
    assignment_filter = request.GET.get('assignment', '').strip()
    if assignment_filter == 'mine' and request.profile.role == UserProfile.Role.OFFICER:
        cases = cases.filter(assigned_officer=request.profile)
    elif assignment_filter == 'unassigned':
        cases = cases.filter(assigned_officer__isnull=True)
    elif assignment_filter == 'all' and request.profile.role == UserProfile.Role.OFFICER:
        cases = cases.filter(Q(assigned_officer=request.profile) | Q(assigned_officer__isnull=True))
    priority = request.GET.get('priority', '').strip()
    if priority:
        cases = cases.filter(priority=priority)
    paginator = Paginator(cases.order_by('-updated_at'), 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'officer/cases.html', {
        'cases': page_obj,
        'current_filter': {
            'status': status,
            'category': category,
            'assignment': assignment_filter,
            'priority': priority,
            'q': query,
        },
        'active_view': 'all' if assignment_filter == 'all' else 'mine' if assignment_filter == 'mine' else 'unassigned' if assignment_filter == 'unassigned' else 'overview',
        'all_filters': {
            'status': ['OPEN', 'UNDER_REVIEW', 'UNDER_INVESTIGATION', 'RESOLVED', 'CLOSED'],
            'priority': [Complaint.Priority.HIGH, Complaint.Priority.MEDIUM, Complaint.Priority.LOW],
        },
    })


@role_required(UserProfile.Role.OFFICER, UserProfile.Role.ADMIN)
@transaction.atomic
def officer_case_details(request, case_id):
    case = _accessible_case(request.profile, case_id)
    original_status = case.status
    original_assigned_officer_id = case.assigned_officer_id
    status_form = CaseStatusForm(request.POST or None, instance=case, prefix='status')
    assignment_form = CaseAssignmentForm(request.POST or None, instance=case, prefix='assignment')
    evidence_form = EvidenceForm(request.POST or None, request.FILES or None, prefix='evidence')
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'status' and status_form.is_valid():
            previous = original_status
            updated = status_form.save(commit=False)
            if updated.status == previous:
                messages.info(request, 'The case already has that status.')
                return redirect('officer_case_details', case_id=case.pk)
            previous_vehicle_status = updated.vehicle.status if updated.vehicle_id else None
            updated.updated_at = timezone.now()
            if updated.status == Case.Status.UNDER_REVIEW and not updated.review_started_at:
                updated.review_started_at = timezone.now()
            if updated.status == Case.Status.UNDER_INVESTIGATION and not updated.investigation_started_at:
                updated.investigation_started_at = timezone.now()
                if updated.vehicle_id:
                    updated.vehicle.status = Vehicle.Status.UNDER_INVESTIGATION
                    updated.vehicle.save(update_fields=['status', 'updated_at'])
                    VehicleTheftReport.objects.filter(vehicle=updated.vehicle).update(
                        status=VehicleTheftReport.Status.UNDER_INVESTIGATION
                    )
            if updated.status == Case.Status.RESOLVED:
                updated.resolved_at = timezone.now()
                if updated.vehicle_id:
                    updated.vehicle.status = Vehicle.Status.RECOVERED
                    updated.vehicle.save(update_fields=['status', 'updated_at'])
                    VehicleTheftReport.objects.filter(vehicle=updated.vehicle).update(status=VehicleTheftReport.Status.RECOVERED)
            if updated.status == Case.Status.CLOSED:
                updated.closed_at = timezone.now()
                if updated.vehicle_id:
                    if updated.vehicle.status != Vehicle.Status.RECOVERED:
                        updated.vehicle.status = Vehicle.Status.CLOSED
                        updated.vehicle.save(update_fields=['status', 'updated_at'])
                    VehicleTheftReport.objects.filter(vehicle=updated.vehicle).update(
                        status=VehicleTheftReport.Status.CLOSED
                    )
            updated.save()
            if updated.vehicle_id and previous_vehicle_status != updated.vehicle.status:
                record_audit(
                    request.profile, 'VEHICLE_UPDATED', updated.vehicle,
                    f'Vehicle status changed from {previous_vehicle_status} to {updated.vehicle.status} through case {updated.case_number}.',
                    request_ip(request),
                )
            if updated.complaint_id:
                updated.complaint.status = _complaint_status_for_case(updated.status)
                updated.complaint.save(update_fields=['status', 'updated_at'])
                notify_user(
                    updated.complaint.complainant, 'Complaint status updated',
                    f'Case {updated.case_number} is now {updated.get_status_display()}.',
                    Notification.Type.CASE,
                )
            record_audit(request.profile, 'CASE_STATUS_CHANGED', updated, f'Case status changed from {previous} to {updated.status}.', request_ip(request))
            messages.success(request, 'Case status updated.')
            return redirect('officer_case_details', case_id=case.pk)
        if action == 'assign' and request.profile.role == UserProfile.Role.ADMIN and assignment_form.is_valid():
            previous_officer_id = original_assigned_officer_id
            updated = assignment_form.save(commit=False)
            if previous_officer_id == updated.assigned_officer_id:
                messages.info(request, 'The case is already assigned to that officer.')
                return redirect('officer_case_details', case_id=case.pk)
            updated.assigned_at = timezone.now() if updated.assigned_officer else None
            updated.save()
            if updated.complaint_id:
                updated.complaint.status = Complaint.Status.ASSIGNED if updated.assigned_officer else Complaint.Status.SUBMITTED
                updated.complaint.save(update_fields=['status', 'updated_at'])
            if updated.assigned_officer_id:
                notify_user(
                    updated.assigned_officer, 'New case assigned',
                    f'Case {updated.case_number} has been assigned to you.',
                    Notification.Type.CASE,
                )
            record_audit(
                request.profile, 'CASE_ASSIGNED', updated,
                f'Case assigned to {updated.assigned_officer or "unassigned"} (previous profile: {previous_officer_id or "unassigned"}).',
                request_ip(request),
            )
            messages.success(request, 'Case assignment updated.')
            return redirect('officer_case_details', case_id=case.pk)
        if action == 'evidence' and evidence_form.is_valid():
            evidence = evidence_form.save(commit=False)
            evidence.case = case
            evidence.uploaded_by = request.profile
            evidence.save()
            record_audit(request.profile, 'EVIDENCE_UPLOADED', evidence, f'Evidence uploaded for case {case.case_number}.', request_ip(request))
            messages.success(request, 'Evidence uploaded to the case.')
            return redirect('officer_case_details', case_id=case.pk)
        if action == 'investigation_note':
            if request.profile.role != UserProfile.Role.OFFICER:
                raise PermissionDenied
            note = request.POST.get('investigation_note', '').strip()
            if not note or len(note) > 4000:
                messages.error(request, 'Enter an investigation note of 1 to 4000 characters.')
                return redirect('officer_case_details', case_id=case.pk)
            else:
                record_audit(
                    request.profile, 'INVESTIGATION_NOTE_ADDED', case,
                    f'Investigation note: {note}', request_ip(request),
                )
                messages.success(request, 'Investigation note added to the case timeline.')
                return redirect('officer_case_details', case_id=case.pk)
        if action not in {'status', 'assign', 'evidence', 'investigation_note'}:
            raise PermissionDenied
    related_evidence_ids = case.evidence.values_list('pk', flat=True)
    audit_events = AuditLog.objects.filter(
        Q(model_name='network.Case', object_id=str(case.pk))
        | Q(model_name='network.Evidence', object_id__in=related_evidence_ids)
        | Q(model_name='network.Vehicle', object_id=str(case.vehicle_id), description__contains=case.case_number)
    ).order_by('timestamp')
    timeline = [{'title': 'Case created', 'timestamp': case.created_at}]
    timeline.extend({'title': event.description, 'timestamp': event.timestamp} for event in audit_events)
    if case.resolved_at:
        timeline.append({'title': 'Case resolved', 'timestamp': case.resolved_at})
    return render(request, 'officer/case_details.html', {
        'case': case,
        'timeline': timeline,
        'status_form': status_form,
        'assignment_form': assignment_form,
        'evidence_form': evidence_form,
    })


@role_required(UserProfile.Role.OFFICER, UserProfile.Role.ADMIN)
def officer_reports(request):
    if request.profile.role == UserProfile.Role.OFFICER:
        cases = Case.objects.filter(assigned_officer=request.profile)
    else:
        cases = Case.objects.all()
    reports = VehicleTheftReport.objects.select_related('vehicle', 'complaint').filter(
        complaint__case__in=cases
    ).distinct()
    return render(request, 'officer/reports.html', {'reports': reports})


@login_required
def evidence_download(request, evidence_id):
    profile = profile_for(request.user)
    evidence = get_object_or_404(Evidence.objects.select_related('case__complaint'), pk=evidence_id)
    if profile.role == UserProfile.Role.CITIZEN:
        if not evidence.case.complaint_id or evidence.case.complaint.complainant_id != profile.pk:
            raise PermissionDenied
    elif profile.role == UserProfile.Role.OFFICER:
        if evidence.case.assigned_officer_id not in {None, profile.pk}:
            raise PermissionDenied
    elif profile.role != UserProfile.Role.ADMIN:
        raise PermissionDenied
    return FileResponse(
        evidence.file.open('rb'),
        as_attachment=True,
        filename=Path(evidence.file.name).name,
    )


@role_required(UserProfile.Role.ADMIN)
def admin_dashboard(request):
    admin_profile = request.profile
    total_cases = Case.objects.count()
    pending_cases = Case.objects.filter(status__in=[Case.Status.OPEN, Case.Status.UNDER_REVIEW]).count()
    active_investigations = Case.objects.filter(status=Case.Status.UNDER_INVESTIGATION).count()
    resolved_cases = Case.objects.filter(status__in=[Case.Status.RESOLVED, Case.Status.CLOSED]).count()
    unassigned_cases = Case.objects.filter(assigned_officer__isnull=True).count()
    high_priority_cases = Case.objects.filter(priority__in=[Complaint.Priority.HIGH, Complaint.Priority.CRITICAL]).count()
    return render(request, 'admin_dashboard.html', {
        'profile': admin_profile,
        'total_users': UserProfile.objects.count(),
        'total_citizens': UserProfile.objects.filter(role=UserProfile.Role.CITIZEN).count(),
        'total_officers': UserProfile.objects.filter(role=UserProfile.Role.OFFICER).count(),
        'total_cases': total_cases,
        'pending_cases': pending_cases,
        'active_cases': active_investigations,
        'resolved_cases': resolved_cases,
        'unassigned_cases': unassigned_cases,
        'high_priority_cases': high_priority_cases,
        'total_complaints': Complaint.objects.count(),
        'stolen_vehicles': Vehicle.objects.filter(status__in=[Vehicle.Status.STOLEN, Vehicle.Status.REPORTED_MISSING]).count(),
        'fraud_reports': FraudReport.objects.count(),
        'high_risk_fraud_reports': FraudReport.objects.filter(risk_level=FraudReport.RiskLevel.HIGH).count(),
        'audit_logs': AuditLog.objects.select_related('user')[:10],
        'recent_cases': Case.objects.select_related('complaint__complainant', 'assigned_officer').order_by('-updated_at')[:6],
    })


@role_required(UserProfile.Role.ADMIN)
def admin_cases(request):
    cases = Case.objects.select_related('complaint__complainant', 'assigned_officer', 'vehicle').order_by('-updated_at')
    query = request.GET.get('q', '').strip()
    if query:
        query_qs = Q(title__icontains=query) | Q(complaint__subject__icontains=query) | Q(complaint__complainant__name__icontains=query) | Q(vehicle__registration_number__icontains=query) | Q(assigned_officer__name__icontains=query)
        try:
            query_num = int(query)
        except ValueError:
            query_num = None
        if query_num is not None:
            query_qs |= Q(pk=query_num)
        cases = cases.filter(query_qs)
    status = request.GET.get('status', '').strip()
    assignment = request.GET.get('assignment', '').strip()
    if assignment == 'unassigned':
        cases = cases.filter(assigned_officer__isnull=True)
    elif assignment == 'all':
        pass
    if status:
        if status == 'pending':
            cases = cases.filter(status__in=[Case.Status.OPEN, Case.Status.UNDER_REVIEW])
        else:
            cases = cases.filter(status=status)
    priority = request.GET.get('priority', '').strip()
    if priority:
        cases = cases.filter(priority=priority)
    officer_id = request.GET.get('officer', '').strip()
    if officer_id:
        cases = cases.filter(assigned_officer_id=officer_id)
    case_type = request.GET.get('case_type', '').strip()
    if case_type:
        cases = cases.filter(category=case_type)
    paginator = Paginator(cases, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'admin_cases.html', {
        'cases': page_obj,
        'current_filter': {
            'q': query,
            'status': status,
            'priority': priority,
            'officer': officer_id,
            'case_type': case_type,
            'assignment': assignment,
        },
        'officers': UserProfile.objects.filter(role=UserProfile.Role.OFFICER).select_related('user').order_by('name'),
        'case_types': [choice[0] for choice in Complaint.Category.choices],
        'profile': request.profile,
    })


@role_required(UserProfile.Role.ADMIN)
def admin_unassigned_cases(request):
    return redirect(f"{reverse('admin_cases')}?assignment=unassigned")


def _officer_cases(profile):
    return Case.objects.filter(Q(assigned_officer=profile) | Q(assigned_officer__isnull=True))


def _accessible_case(profile, case_id):
    case = get_object_or_404(Case.objects.select_related('complaint__complainant', 'vehicle', 'assigned_officer'), pk=case_id)
    if profile.role == UserProfile.Role.OFFICER and case.assigned_officer_id not in {None, profile.pk}:
        raise PermissionDenied
    if profile.role == UserProfile.Role.CITIZEN and (
        not case.complaint_id or case.complaint.complainant_id != profile.pk
    ):
        raise PermissionDenied
    return case


def _complaint_status_for_case(status):
    return {
        Case.Status.OPEN: Complaint.Status.SUBMITTED,
        Case.Status.UNDER_REVIEW: Complaint.Status.UNDER_REVIEW,
        Case.Status.UNDER_INVESTIGATION: Complaint.Status.UNDER_INVESTIGATION,
        Case.Status.RESOLVED: Complaint.Status.RESOLVED,
        Case.Status.CLOSED: Complaint.Status.CLOSED,
    }[status]
