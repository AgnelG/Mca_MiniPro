from django.contrib import admin
from django.contrib.auth.views import PasswordResetCompleteView, PasswordResetConfirmView
from django.urls import path
from project import views

urlpatterns = [
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin/cases/', views.admin_cases, name='admin_cases'),
    path('admin/unassigned-cases/', views.admin_unassigned_cases, name='admin_unassigned_cases'),
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('vehicles/report/', views.vehicle_report, name='vehicles_report'),
    path('vehicles/search/', views.vehicle_search, name='vehicles_search'),
    path('vehicles/details/<int:vehicle_id>/', views.vehicle_details, name='vehicles_details'),
    path('vehicles/contact/<int:case_id>/', views.contact_reporter, name='vehicles_contact'),
    path('fraud/check/', views.fraud_check, name='fraud_check'),
    path('fraud/result/', views.fraud_result, name='fraud_result'),
    path('complaints/create/', views.complaint_create, name='complaints_create'),
    path('complaints/list/', views.complaint_list, name='complaints_list'),
    path('complaints/details/<int:complaint_id>/', views.complaint_details, name='complaints_details'),
    path('notifications/', views.notifications_list, name='notifications_list'),
    path('accounts/login/', views.login_view, name='accounts_login'),
    path('accounts/register/', views.register_view, name='accounts_register'),
    path('accounts/password-reset/', views.password_reset_view, name='accounts_password_reset'),
    path(
        'accounts/password-reset/<uidb64>/<token>/',
        PasswordResetConfirmView.as_view(template_name='accounts/password_reset_confirm.html'),
        name='password_reset_confirm',
    ),
    path(
        'accounts/password-reset/complete/',
        PasswordResetCompleteView.as_view(template_name='accounts/password_reset_complete.html'),
        name='password_reset_complete',
    ),
    path('accounts/profile/', views.profile_view, name='accounts_profile'),
    path('accounts/logout/', views.logout_view, name='accounts_logout'),
    path('citizen/dashboard/', views.citizen_dashboard, name='citizen_dashboard'),
    path('officer/dashboard/', views.officer_dashboard, name='officer_dashboard'),
    path('officer/cases/', views.officer_cases, name='officer_cases'),
    path('officer/cases/<int:case_id>/', views.officer_case_details, name='officer_case_details'),
    path('cases/evidence/<int:evidence_id>/', views.evidence_download, name='evidence_download'),
    path('officer/reports/', views.officer_reports, name='officer_reports'),
]
