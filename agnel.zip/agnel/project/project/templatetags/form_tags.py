from django import template
from django.utils.safestring import mark_safe

register = template.Library()

@register.filter(name='add_class')
def add_class(field, css_class):
    """Add a CSS class to Django form fields and support demo field markup."""
    if not hasattr(field, 'as_widget') or not hasattr(field, 'field'):
        return mark_safe(str(field))
    existing = field.field.widget.attrs.get('class', '')
    attrs = {'class': (existing + ' ' + css_class).strip()}
    return field.as_widget(attrs=attrs)
